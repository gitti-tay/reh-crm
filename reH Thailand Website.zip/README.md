
  # Publish Figma Design Online

  This is a code bundle for Publish Figma Design Online. The original project is available at https://www.figma.com/design/5VRT61RPgFEXIZVEs9RUoG/Publish-Figma-Design-Online.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  