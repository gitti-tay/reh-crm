import { useState } from "react";
import svgPaths from "../../imports/svg-sqg3bg9ea9";

const regions = ["All Regions", "Bangkok", "Chiang Mai", "Phuket", "Pattaya"];

const clinics = [
  {
    name: "APEX Surgery Hospital - Ploenchit",
    address: "82 Sukhumvit Rd, Bangkok",
    hours: "Daily: 8:30-20:30",
    tags: ["Surgical Procedures", "Advanced Aesthetics"],
    region: "Bangkok",
  },
  {
    name: "APEX Beauty - Thonglor",
    address: "Thonglor Soi 8, Sukhumvit, Bangkok",
    hours: "Daily: 8:30-20:00",
    tags: ["Skin Rejuvenation", "SSCM Treatments"],
    region: "Bangkok",
  },
  {
    name: "APEX Beauty - Siam Paragon",
    address: "Siam Paragon, Bangkok",
    hours: "Daily: 10:00-21:00",
    tags: ["Facial Treatments", "Pigmentation"],
    region: "Bangkok",
  },
  {
    name: "APEX Beauty - EmQuartier",
    address: "EmQuartier, Sukhumvit, Bangkok",
    hours: "Daily: 10:00-21:00",
    tags: ["Medical Aesthetics", "Microneedling"],
    region: "Bangkok",
  },
  {
    name: "APEX Beauty - Dusit Central",
    address: "Dusit Central Park, Bangkok",
    hours: "Daily: 10:30-22:00",
    tags: ["Advanced Skincare", "Anti-Aging"],
    region: "Bangkok",
  },
  {
    name: "S-Mart Anti-aging Wellness",
    address: "Bangkok",
    hours: "Daily: 09:00-19:00",
    tags: ["Anti-Aging", "Wellness Programs"],
    region: "Bangkok",
  },
];

export function ClinicFinderSection() {
  const [activeRegion, setActiveRegion] = useState("All Regions");
  const [search, setSearch] = useState("");

  const filteredClinics = clinics.filter((c) => {
    const matchRegion = activeRegion === "All Regions" || c.region === activeRegion;
    const matchSearch = !search || c.name.toLowerCase().includes(search.toLowerCase()) || c.address.toLowerCase().includes(search.toLowerCase());
    return matchRegion && matchSearch;
  });

  return (
    <section id="find-clinic" className="bg-gradient-to-b from-white via-[#f9fafb] to-white py-16 lg:py-24 overflow-hidden">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-12">
        {/* Badge */}
        <div className="flex justify-center mb-4">
          <div className="inline-flex items-center gap-2 bg-[#eff6ff] border border-[#bedbff] rounded-full px-4 py-2">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <path d={svgPaths.p14548f00} stroke="#155DFC" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33" />
              <path d={svgPaths.p17781bc0} stroke="#155DFC" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33" />
            </svg>
            <span className="font-['Inter',sans-serif] font-semibold text-[14px] text-[#1447e6] tracking-[-0.15px]">
              6+ Certified Locations
            </span>
          </div>
        </div>

        {/* Header */}
        <div className="text-center mb-8">
          <h2 className="font-['Inter',sans-serif] font-bold text-[32px] md:text-[40px] lg:text-[48px] text-[#101828] tracking-[-0.13px] mb-4">
            Find re:H Certified Clinic
          </h2>
          <p className="font-['Inter',sans-serif] font-normal text-[16px] md:text-[18px] text-[#4a5565] tracking-[-0.44px]">
            SSCM technology available exclusively at certified medical facilities
          </p>
        </div>

        {/* Search */}
        <div className="max-w-[576px] mx-auto mb-6 relative">
          <svg className="absolute left-4 top-1/2 -translate-y-1/2" width="18" height="18" viewBox="0 0 18 18" fill="none">
            <path d={svgPaths.p126da180} stroke="#99A1AF" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p89d1980} stroke="#99A1AF" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </svg>
          <input
            type="text"
            placeholder="Search by clinic or location..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full h-[46px] pl-12 pr-4 rounded-[10px] border border-[#d1d5dc] font-['Inter',sans-serif] font-normal text-[14px] text-[#0a0a0a] tracking-[-0.15px] outline-none focus:border-[#155dfc] transition-colors bg-white"
          />
        </div>

        {/* Region Filters */}
        <div className="flex flex-wrap justify-center gap-2 mb-8">
          {regions.map((region) => (
            <button
              key={region}
              onClick={() => setActiveRegion(region)}
              className={`px-5 py-2 rounded-full font-['Inter',sans-serif] font-medium text-[14px] tracking-[0.13px] cursor-pointer transition-colors border ${
                activeRegion === region
                  ? "bg-[#155dfc] text-white border-[#155dfc] shadow-[0px_10px_15px_rgba(0,0,0,0.1)]"
                  : "bg-white text-[#364153] border-[#e5e7eb] hover:border-[#155dfc]"
              }`}
            >
              {region}
            </button>
          ))}
        </div>

        {/* Clinic Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-10">
          {filteredClinics.map((clinic) => (
            <div key={clinic.name} className="bg-white rounded-[14px] border-2 border-[#e5e7eb] p-5">
              <div className="flex items-start justify-between mb-3">
                <div className="bg-[#dbeafe] rounded-[10px] w-10 h-10 flex items-center justify-center">
                  <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                    <path d={svgPaths.p3b43bb80} stroke="#155DFC" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.67" />
                    <path d={svgPaths.p1d7f0000} stroke="#155DFC" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.67" />
                    <path d={svgPaths.p2b722f80} stroke="#155DFC" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.67" />
                  </svg>
                </div>
                <span className="bg-[#dbeafe] rounded-full px-2 py-1 font-['Inter',sans-serif] font-bold text-[12px] text-[#1447e6]">
                  CERTIFIED
                </span>
              </div>

              <h3 className="font-['Inter',sans-serif] font-bold text-[14px] text-[#101828] tracking-[-0.29px] mb-3">
                {clinic.name}
              </h3>

              <div className="flex flex-col gap-2 mb-4">
                <div className="flex items-center gap-2">
                  <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                    <path d={svgPaths.pba7ec40} stroke="#4A5565" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.17" />
                    <path d={svgPaths.pbd96b00} stroke="#4A5565" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.17" />
                  </svg>
                  <span className="font-['Inter',sans-serif] font-normal text-[12px] text-[#4a5565]">{clinic.address}</span>
                </div>
                <div className="flex items-center gap-2">
                  <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                    <path d={svgPaths.p34cde680} stroke="#4A5565" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.17" />
                    <path d="M7 3.5V7L9.33 8.17" stroke="#4A5565" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.17" />
                  </svg>
                  <span className="font-['Inter',sans-serif] font-normal text-[12px] text-[#4a5565]">{clinic.hours}</span>
                </div>
              </div>

              <div className="flex flex-wrap gap-1.5 mb-4">
                {clinic.tags.map((tag) => (
                  <span key={tag} className="bg-[#f3f4f6] rounded-full px-2 py-1 font-['Inter',sans-serif] font-normal text-[12px] text-[#364153]">
                    {tag}
                  </span>
                ))}
              </div>

              <button className="w-full bg-[#155dfc] rounded-[10px] py-2.5 font-['Inter',sans-serif] font-medium text-[14px] text-white tracking-[0.13px] cursor-pointer border-none hover:bg-[#1447e6] transition-colors flex items-center justify-center gap-2">
                <span>Directions</span>
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                  <path d={svgPaths.p9d0d100} stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33" />
                </svg>
              </button>
            </div>
          ))}
        </div>

        {/* Partner CTA */}
        <div id="clinics" className="bg-gradient-to-r from-[#155dfc] to-[#193cb8] rounded-2xl p-8 lg:p-12 text-center relative overflow-hidden shadow-[0px_25px_50px_-12px_rgba(0,0,0,0.25)]">
          <div className="absolute top-0 right-20 w-48 h-48 rounded-full bg-white/10 blur-[64px]" />
          <h3 className="font-['Inter',sans-serif] font-bold text-[20px] md:text-[24px] text-white tracking-[-0.17px] mb-3 relative z-10">
            Become an re:H Partner
          </h3>
          <p className="font-['Inter',sans-serif] font-normal text-[14px] md:text-[16px] text-[#dbeafe] max-w-[700px] mx-auto mb-6 leading-[1.5] tracking-[-0.31px] relative z-10">
            Join Thailand's leading network of aesthetic clinics offering precision SSCM technology
          </p>
          <button className="bg-white text-[#155dfc] rounded-[10px] px-8 py-3.5 font-['Inter',sans-serif] font-semibold text-[16px] tracking-[0.0075px] cursor-pointer border-none shadow-[0px_10px_15px_rgba(0,0,0,0.1)] hover:bg-[#f8f9fa] transition-colors relative z-10">
            Partner Enquiry
          </button>
        </div>
      </div>
    </section>
  );
}
