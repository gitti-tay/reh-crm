import imgBalloonTip from "figma:asset/7896ee4d366a79dfea26a74a6685ceb61b6ae8e3.png";
import imgBlowTip from "figma:asset/bb6d03e4b9f9797975804e5ffaf53ce2454977f9.png";
import svgPaths from "../../imports/svg-sqg3bg9ea9";

const comparisonRows = [
  { label: "Depth Control", traditional: "Manual adjustment", rf: "Semi-automatic", sscm: "✓ Digital ±0.01mm" },
  { label: "Accuracy", traditional: "±0.1–0.2mm variance", rf: "±0.05mm variance", sscm: "✓ 99.7% precision" },
  { label: "Drug Delivery", traditional: "Topical absorption", rf: "Heat + channels", sscm: "✓ Air subcision + Drug Delivery" },
  { label: "Safety System", traditional: "Basic sensors", rf: "Thermal monitoring", sscm: "✓ 13-point array" },
  { label: "Treatment Time", traditional: "15-20 min", rf: "12-15 min", sscm: "✓ ~15 min (3,000 shots)" },
];

const indications = [
  {
    title: "Acne Scars",
    icon: (
      <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
        <path d={svgPaths.p14d24500} stroke="#155DFC" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.67" />
        <path d={svgPaths.p240d7000} stroke="#155DFC" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.67" />
        <path d={svgPaths.p25499600} stroke="#155DFC" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.67" />
      </svg>
    ),
    description: (
      <>
        <span className="font-bold text-[#1447e6]">Air subcision</span>{" "}
        creates pneumatic pressure between dermis layers, mechanically releasing fibrotic bands and lifting atrophic scars from beneath without thermal damage.
      </>
    ),
  },
  {
    title: "Pore Refinement",
    icon: (
      <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
        <path d={svgPaths.p3161fe80} stroke="#155DFC" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.67" />
      </svg>
    ),
    description: (
      <>
        Positive pressure delivery stimulates{" "}
        <span className="font-bold text-[#1447e6]">sebaceous gland remodeling</span>{" "}
        and collagen compaction around pore structures, reducing diameter by 40-45% without ablative injury.
      </>
    ),
  },
  {
    title: "Pigmentation",
    icon: (
      <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
        <path d={svgPaths.p2898e700} stroke="#155DFC" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.67" />
      </svg>
    ),
    description: (
      <>
        <span className="font-semibold text-[#155dfc]">Controlled microchannel injection</span>{" "}
        delivers tyrosinase inhibitors directly to melanocyte clusters at DEJ (0.5-0.8mm), achieving 400% higher absorption vs topical application.
      </>
    ),
  },
];

export function ComparisonSection() {
  return (
    <section id="technology" className="bg-gradient-to-b from-white via-[#f9fafb] to-white py-16 lg:py-24 overflow-hidden">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-12">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="font-['Inter',sans-serif] font-bold text-[32px] md:text-[40px] lg:text-[48px] text-[#101828] tracking-[-0.13px] mb-4">
            What Makes SSCM™ Different?
          </h2>
          <p className="font-['Inter',sans-serif] font-normal text-[16px] md:text-[18px] text-[#4a5565] max-w-[630px] mx-auto leading-[1.6] tracking-[-0.44px]">
            Engineering-level precision with patented air subcision technology for superior clinical outcomes
          </p>
        </div>

        {/* Comparison Table */}
        <div className="bg-white rounded-2xl border border-[#e5e7eb] shadow-[0px_20px_25px_-5px_rgba(0,0,0,0.1),0px_8px_10px_-6px_rgba(0,0,0,0.1)] overflow-hidden mb-10">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[700px]">
              <thead>
                <tr>
                  <th className="p-6 text-left font-['Inter',sans-serif] font-bold text-[14px] text-[#101828] tracking-[0.55px] uppercase" style={{ backgroundImage: "linear-gradient(123deg, #f9fafb, #f3f4f6)" }}>
                    Comparison
                  </th>
                  <th className="p-6 text-center bg-white border-l border-[#e5e7eb]">
                    <div className="flex flex-col items-center gap-1">
                      <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                        <path d={svgPaths.pace200} stroke="#99A1AF" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
                        <path d="M12 8V12" stroke="#99A1AF" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
                        <path d="M12 16H12.01" stroke="#99A1AF" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
                      </svg>
                      <span className="font-['Inter',sans-serif] font-bold text-[14px] text-[#101828]">Traditional</span>
                    </div>
                  </th>
                  <th className="p-6 text-center bg-[rgba(255,247,237,0.5)] border-l border-[#e5e7eb]">
                    <div className="flex flex-col items-center gap-1">
                      <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                        <path d={svgPaths.p6428280} stroke="#FF6900" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
                      </svg>
                      <span className="font-['Inter',sans-serif] font-bold text-[14px] text-[#101828]">RF Energy</span>
                    </div>
                  </th>
                  <th className="p-6 text-center border-l border-[#e5e7eb]" style={{ backgroundImage: "linear-gradient(123deg, #155dfc, #1447e6)" }}>
                    <div className="flex flex-col items-center gap-1">
                      <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                        <path d={svgPaths.p1b8b3180} stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
                      </svg>
                      <span className="font-['Inter',sans-serif] font-bold text-[20px] text-white">re:H SSCM™</span>
                    </div>
                  </th>
                </tr>
              </thead>
              <tbody>
                {comparisonRows.map((row, i) => (
                  <tr key={row.label} className={i < comparisonRows.length - 1 ? "border-t border-[#e5e7eb]" : ""}>
                    <td className="px-6 py-4 font-['Inter',sans-serif] font-medium text-[14px] text-[#364153]" style={{ backgroundImage: "linear-gradient(123deg, #f9fafb, #f3f4f6)" }}>
                      {row.label}
                    </td>
                    <td className="px-6 py-4 font-['Inter',sans-serif] font-normal text-[14px] text-[#4a5565] bg-white border-l border-[#e5e7eb]">
                      {row.traditional}
                    </td>
                    <td className="px-6 py-4 font-['Inter',sans-serif] font-normal text-[14px] text-[#4a5565] bg-[rgba(255,247,237,0.5)] border-l border-[#e5e7eb]">
                      {row.rf}
                    </td>
                    <td className="px-6 py-4 font-['Inter',sans-serif] font-medium text-[16px] md:text-[18px] text-[#eff6ff] border-l border-[#e5e7eb]" style={{ backgroundImage: "linear-gradient(123deg, #155dfc, #1447e6)" }}>
                      {row.sscm}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Indication Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
          {indications.map((item) => (
            <div key={item.title} className="bg-white rounded-[14px] border-2 border-[#e5e7eb] p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="bg-[#dbeafe] rounded-[10px] w-10 h-10 flex items-center justify-center flex-shrink-0">
                  {item.icon}
                </div>
                <h3 className="font-['Inter',sans-serif] font-bold text-[24px] md:text-[28px] text-[#101828] tracking-[-0.31px]">
                  {item.title}
                </h3>
              </div>
              <p className="font-['Inter',sans-serif] font-normal text-[14px] text-[#4a5565] leading-[1.6] tracking-[-0.15px]">
                {item.description}
              </p>
            </div>
          ))}
        </div>

        {/* Tip Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-10">
          {/* Balloon Tip */}
          <div className="bg-white rounded-[14px] border border-[#e5e7eb] shadow-[0px_10px_15px_-3px_rgba(0,0,0,0.1)] overflow-hidden flex flex-col sm:flex-row">
            <div className="sm:w-[216px] h-[200px] sm:h-auto flex-shrink-0" style={{ backgroundImage: "linear-gradient(128deg, #eff6ff, #f9fafb)" }}>
              <div className="w-full h-full flex items-center justify-center p-4">
                <img src={imgBalloonTip} alt="Balloon Tip Technology" className="max-w-full max-h-full object-contain" />
              </div>
            </div>
            <div className="p-6 flex-1">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-2 h-2 rounded-full bg-[#155dfc]" />
                <h4 className="font-['Inter',sans-serif] font-bold text-[20px] text-[#101828] tracking-[-0.45px]">Balloon Tip™</h4>
              </div>
              <p className="font-['Inter',sans-serif] font-normal text-[14px] text-[#4a5565] leading-[1.6] tracking-[-0.15px] mb-4">
                Patented pressure control creates micro-subcision and delivers concentrated solution, facilitating absorption of surface-applied compounds to intended dermal depths.
              </p>
              <div className="flex gap-3">
                <div className="bg-[#f9fafb] rounded-[10px] px-3 py-2 flex-1">
                  <p className="font-['Inter',sans-serif] font-normal text-[12px] text-[#6a7282]">Needle</p>
                  <p className="font-['Inter',sans-serif] font-bold text-[20px] text-[#101828] tracking-[-0.31px]">13 pin</p>
                </div>
                <div className="bg-[#f9fafb] rounded-[10px] px-3 py-2 flex-1">
                  <p className="font-['Inter',sans-serif] font-normal text-[12px] text-[#6a7282]">Depth</p>
                  <p className="font-['Inter',sans-serif] font-bold text-[16px] text-[#101828] tracking-[-0.31px]">0.25–4.00mm</p>
                </div>
              </div>
            </div>
          </div>

          {/* Blow Tip */}
          <div className="bg-white rounded-[14px] border border-[#e5e7eb] shadow-[0px_10px_15px_-3px_rgba(0,0,0,0.1)] overflow-hidden flex flex-col sm:flex-row">
            <div className="sm:w-[216px] h-[200px] sm:h-auto flex-shrink-0" style={{ backgroundImage: "linear-gradient(128deg, #eff6ff, #f9fafb)" }}>
              <div className="w-full h-full flex items-center justify-center p-4">
                <img src={imgBlowTip} alt="Blow Tip Technology" className="max-w-full max-h-full object-contain" />
              </div>
            </div>
            <div className="p-6 flex-1">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-2 h-2 rounded-full bg-[#155dfc]" />
                <h4 className="font-['Inter',sans-serif] font-bold text-[20px] text-[#101828] tracking-[-0.45px]">Blow Tip™</h4>
              </div>
              <p className="font-['Inter',sans-serif] font-normal text-[14px] text-[#4a5565] leading-[1.6] tracking-[-0.15px] mb-4">
                Positive pressure generation during needle retraction delivers compounds uniformly across treatment zones with precision air subcision effect.
              </p>
              <div className="flex gap-3">
                <div className="bg-[#f9fafb] rounded-[10px] px-3 py-2 flex-1">
                  <p className="font-['Inter',sans-serif] font-normal text-[12px] text-[#6a7282]">Needle</p>
                  <p className="font-['Inter',sans-serif] font-bold text-[20px] text-[#101828] tracking-[-0.31px]">16 pin</p>
                </div>
                <div className="bg-[#f9fafb] rounded-[10px] px-3 py-2 flex-1">
                  <p className="font-['Inter',sans-serif] font-normal text-[12px] text-[#6a7282]">Depth</p>
                  <p className="font-['Inter',sans-serif] font-bold text-[16px] text-[#101828] tracking-[-0.31px]">0.25–4.00mm</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Patent callout */}
        <div className="bg-[#eff6ff] rounded-tr-[10px] rounded-br-[10px] border-l-4 border-[#155dfc] p-6 flex items-start gap-4">
          <div className="bg-[#155dfc] rounded-full w-10 h-10 flex items-center justify-center flex-shrink-0">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
              <path d={svgPaths.pa28c500} stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.67" />
            </svg>
          </div>
          <div>
            <h4 className="font-['Inter',sans-serif] font-bold text-[16px] text-[#101828] tracking-[-0.31px] mb-1">
              Patented Korean Technology (KR 10-2604809, KR 10-2669940)
            </h4>
            <p className="font-['Inter',sans-serif] font-normal text-[14px] text-[#4a5565] leading-[1.6] tracking-[-0.15px]">
              SSCM™ combines Balloon Tip™ and Blow Tip™ with Stacking Mode (up to 3 depths per shot) to deliver microneedling elevated to medical-device precision—supporting well-balanced treatments for optimal clinical outcomes.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
