import { Navigation } from "./components/Navigation";
import { HeroSection } from "./components/HeroSection";
import { ComparisonSection } from "./components/ComparisonSection";
import { VideoSection } from "./components/VideoSection";
import { TestimonialsSection } from "./components/TestimonialsSection";
import { ClinicFinderSection } from "./components/ClinicFinderSection";
import { CTASection } from "./components/CTASection";
import { Footer } from "./components/Footer";

export default function App() {
  return (
    <div className="min-h-screen bg-white font-['Inter',sans-serif] overflow-x-hidden">
      <Navigation />
      <HeroSection />
      <ComparisonSection />
      <VideoSection />
      <TestimonialsSection />
      <ClinicFinderSection />
      <CTASection />
      <Footer />
    </div>
  );
}
