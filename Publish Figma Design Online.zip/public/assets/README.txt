ASSET FILES FOR re:H THAILAND WEBSITE
======================================

Place the following image files from your Figma Make export in this directory:

1. 000ca9a8272dd470779cfc014e6e294d7d9e5dba.png  (re:H SSCM Device image - used in Hero section)
2. 7896ee4d366a79dfea26a74a6685ceb61b6ae8e3.png  (Balloon Tip technology image - used in Comparison section)
3. bb6d03e4b9f9797975804e5ffaf53ce2454977f9.png  (Blow Tip technology image - used in Comparison section)
4. 1ffbd753ec27789a617aa37d799e86f2761e08d5.png  (re:H Thailand logo - used in Navigation and Footer)

These files are referenced by the code via figma:asset/ imports.
The Vite plugin in vite.config.ts resolves them from this directory.

For the video file, place it at:
  public/assets/videos/sscm-showcase.mp4
