import svgPaths from "./svg-sqg3bg9ea9";
import imgImageReHSscmDevice from "figma:asset/000ca9a8272dd470779cfc014e6e294d7d9e5dba.png";
import imgImageBalloonTipTechnology from "figma:asset/7896ee4d366a79dfea26a74a6685ceb61b6ae8e3.png";
import imgImageBlowTipTechnology from "figma:asset/bb6d03e4b9f9797975804e5ffaf53ce2454977f9.png";
import imgImageReHThailand from "figma:asset/1ffbd753ec27789a617aa37d799e86f2761e08d5.png";

function Container() {
  return <div className="absolute h-[1237.891px] left-0 opacity-2 top-0 w-[1171px]" data-name="Container" style={{ backgroundImage: "url(\'data:image/svg+xml;utf8,<svg viewBox=\\'0 0 1171 1237.9\\' xmlns=\\'http://www.w3.org/2000/svg\\' preserveAspectRatio=\\'none\\'><rect x=\\'0\\' y=\\'0\\' height=\\'100%\\' width=\\'100%\\' fill=\\'url(%23grad)\\' opacity=\\'1\\'/><defs><radialGradient id=\\'grad\\' gradientUnits=\\'userSpaceOnUse\\' cx=\\'0\\' cy=\\'0\\' r=\\'10\\' gradientTransform=\\'matrix(0 -85.2 -85.2 0 585.5 618.95)\\'><stop stop-color=\\'rgba(10,10,10,1)\\' offset=\\'0.00085397\\'/><stop stop-color=\\'rgba(0,0,0,0)\\' offset=\\'0\\'/></radialGradient></defs></svg>\')" }} />;
}

function Container1() {
  return <div className="absolute blur-[64px] left-[278.25px] rounded-[33554400px] size-[600px] top-[309.47px]" data-name="Container" style={{ backgroundImage: "linear-gradient(135deg, rgba(239, 246, 255, 0.4) 0%, rgba(0, 0, 0, 0) 100%)" }} />;
}

function Container2() {
  return <div className="absolute blur-[64px] left-[292.75px] rounded-[33554400px] size-[500px] top-[428.42px]" data-name="Container" style={{ backgroundImage: "linear-gradient(135deg, rgba(255, 251, 235, 0.3) 0%, rgba(0, 0, 0, 0) 100%)" }} />;
}

function Container6() {
  return <div className="absolute bg-gradient-to-b from-[#c9a962] left-[20px] rounded-[33554400px] size-[6px] to-[#e5d4a6] top-[15px]" data-name="Container" />;
}

function Text() {
  return (
    <div className="absolute content-stretch flex h-[16px] items-start left-[38px] top-[10px] w-[252.422px]" data-name="Text">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#364153] text-[12px] tracking-[1.8px] uppercase">TFDA Certified Medical Device</p>
    </div>
  );
}

function Container5() {
  return (
    <div className="absolute bg-[rgba(255,255,255,0.6)] border border-[#e5e7eb] border-solid h-[38px] left-0 rounded-[33554400px] top-0 w-[312.422px]" data-name="Container">
      <Container6 />
      <Text />
    </div>
  );
}

function Text1() {
  return <div className="absolute h-[85px] left-0 top-[146.19px] w-[303.656px]" data-name="Text" />;
}

function Heading() {
  return (
    <div className="h-[226.781px] relative shrink-0 w-full" data-name="Heading 1">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[75.6px] left-0 not-italic text-[#0a0a0a] text-[72px] top-[1.45px] tracking-[-1.677px] w-[547px] whitespace-pre-wrap">
        {`Advanced `}
        <br aria-hidden="true" />
        Air Subcision
        <br aria-hidden="true" />
        Microneedling
      </p>
      <Text1 />
    </div>
  );
}

function Paragraph() {
  return (
    <div className="h-[117px] not-italic relative shrink-0 w-[580px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Light',sans-serif] font-light leading-[0] left-0 text-[#4a5565] text-[0px] text-[20px] top-[58.67px] tracking-[0.6703px] w-[514px] whitespace-pre-wrap">
        <span className="leading-[39px]">{`Introducing the patented SSCM platform delivers precise air subcision and drug delivery with `}</span>
        <span className="font-['Inter:Bold',sans-serif] font-bold leading-[39px]">{`±0.01mm `}</span>
        <span className="font-['Inter:Regular',sans-serif] font-normal leading-[39px]">{`depth control and `}</span>
        <span className="font-['Inter:Bold',sans-serif] font-bold leading-[39px]">minimal pain</span>
        <span className="font-['Inter:Regular',sans-serif] font-normal leading-[39px]">{` level`}</span>
      </p>
      <p className="absolute bg-clip-text font-['Inter:Bold',sans-serif] font-bold leading-[75.6px] left-0 text-[72px] text-[rgba(0,0,0,0)] top-[-19.33px] tracking-[-1.677px]" style={{ backgroundImage: "linear-gradient(90deg, rgba(0, 0, 0, 0) 0%, rgba(0, 0, 0, 0) 100%), linear-gradient(rgb(30, 64, 175) 0%, rgb(59, 130, 246) 50%, rgb(96, 165, 250) 100%)", WebkitTextFillColor: "transparent" }}>
        with Precision
      </p>
    </div>
  );
}

function Container7() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[24px] h-[367.781px] items-start left-0 top-[78px] w-[489.5px]" data-name="Container">
      <Heading />
      <Paragraph />
    </div>
  );
}

function Container8() {
  return <div className="absolute h-[131px] left-0 top-[661.45px] w-[489.5px]" data-name="Container" />;
}

function Container10() {
  return <div className="absolute bg-[#c9a962] left-0 rounded-[33554400px] size-[4px] top-[10px]" data-name="Container" />;
}

function Text2() {
  return (
    <div className="absolute content-stretch flex h-[17px] items-start left-0 top-[2px] w-[159.406px]" data-name="Text">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[22.75px] not-italic relative shrink-0 text-[#0a0a0a] text-[14px] tracking-[-0.1504px]">13-point safety sensors</p>
    </div>
  );
}

function Paragraph1() {
  return (
    <div className="absolute h-[45.5px] left-[20px] top-0 w-[469.5px]" data-name="Paragraph">
      <Text2 />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[18px] leading-[22.75px] left-0 not-italic text-[#364153] text-[14px] top-[24.67px] tracking-[-0.1504px] w-[455px] whitespace-pre-wrap">with real-time monitoring for absolute clinical safety</p>
    </div>
  );
}

function Container9() {
  return (
    <div className="absolute h-[45.5px] left-0 top-[526.45px] w-[489.5px]" data-name="Container">
      <Container10 />
      <Paragraph1 />
    </div>
  );
}

function Container12() {
  return <div className="absolute bg-[#c9a962] left-0 rounded-[33554400px] size-[4px] top-[10px]" data-name="Container" />;
}

function Text3() {
  return (
    <div className="absolute content-stretch flex h-[17px] items-start left-0 top-[2px] w-[173.953px]" data-name="Text">
      <p className="flex-[1_0_0] font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[22.75px] min-h-px min-w-px not-italic relative text-[#0a0a0a] text-[14px] tracking-[-0.1504px] whitespace-pre-wrap">{`Balloon Tip™ & Blow Tip™`}</p>
    </div>
  );
}

function Paragraph2() {
  return (
    <div className="absolute h-[22.75px] left-[20px] top-0 w-[396.172px]" data-name="Paragraph">
      <Text3 />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[22.75px] left-[173.95px] not-italic text-[#364153] text-[14px] top-0 tracking-[-0.1504px]">patented air subcision technology</p>
    </div>
  );
}

function Container11() {
  return (
    <div className="absolute h-[22.75px] left-0 top-[587.95px] w-[489.5px]" data-name="Container">
      <Container12 />
      <Paragraph2 />
    </div>
  );
}

function Container14() {
  return <div className="absolute bg-[#c9a962] left-0 rounded-[33554400px] size-[4px] top-[10px]" data-name="Container" />;
}

function Text4() {
  return (
    <div className="absolute content-stretch flex h-[17px] items-start left-0 top-[2px] w-[153.172px]" data-name="Text">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[22.75px] not-italic relative shrink-0 text-[#0a0a0a] text-[14px] tracking-[-0.1504px]">TFDA 66-1-02-0-0018</p>
    </div>
  );
}

function Paragraph3() {
  return (
    <div className="absolute h-[22.75px] left-[20px] top-0 w-[382.875px]" data-name="Paragraph">
      <Text4 />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[22.75px] left-[153.17px] not-italic text-[#364153] text-[14px] top-0 tracking-[-0.1504px]">• ISO 13485:2016 • Korean Patents</p>
    </div>
  );
}

function Container13() {
  return (
    <div className="absolute h-[22.75px] left-0 top-[626.7px] w-[489.5px]" data-name="Container">
      <Container14 />
      <Paragraph3 />
    </div>
  );
}

function Text5() {
  return (
    <div className="h-[41px] relative shrink-0 w-full" data-name="Text">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[54px] not-italic text-[#101828] text-[14px] text-center top-[-1px] tracking-[0.9696px] uppercase w-[108px] whitespace-pre-wrap">Explore Technology</p>
    </div>
  );
}

function Button() {
  return (
    <div className="absolute content-stretch flex flex-col h-[84px] items-start left-[271.95px] pb-[2px] pt-[22px] px-[55px] top-[24px] w-[217.547px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-2 border-[#101828] border-solid inset-0 pointer-events-none" />
      <Text5 />
    </div>
  );
}

function Container16() {
  return <div className="absolute bg-gradient-to-r from-[rgba(0,0,0,0)] h-[84px] left-[-255.95px] to-[rgba(0,0,0,0)] top-0 via-1/2 via-[rgba(255,255,255,0.2)] w-[255.953px]" data-name="Container" />;
}

function Icon() {
  return (
    <div className="absolute h-[18px] left-[163.06px] top-[11px] w-[12.891px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12.8906 18">
        <g id="Icon">
          <path d="M2.68555 9.44531H10.2051" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.07422" />
          <path d={svgPaths.p708fe00} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.07422" />
        </g>
      </svg>
    </div>
  );
}

function Text6() {
  return (
    <div className="absolute h-[40px] left-[40px] top-[22px] w-[175.953px]" data-name="Text">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[75.66px] not-italic text-[14px] text-center text-white top-0 tracking-[0.9696px] uppercase w-[123px] whitespace-pre-wrap">Schedule Clinical Demo</p>
      <Icon />
    </div>
  );
}

function Button1() {
  return (
    <div className="absolute bg-gradient-to-b from-[#0a0a0a] h-[84px] left-0 overflow-clip to-[#1a1a1a] top-[24px] w-[255.953px]" data-name="Button">
      <Container16 />
      <Text6 />
    </div>
  );
}

function Container15() {
  return (
    <div className="absolute h-[108px] left-0 top-[669.78px] w-[489.5px]" data-name="Container">
      <Button />
      <Button1 />
    </div>
  );
}

function Container4() {
  return (
    <div className="absolute h-[920.781px] left-0 top-[86.55px] w-[489.5px]" data-name="Container">
      <Container5 />
      <Container7 />
      <Container8 />
      <Container9 />
      <Container11 />
      <Container13 />
      <Container15 />
    </div>
  );
}

function Container19() {
  return <div className="blur-[64px] rounded-[33554400px] shrink-0 size-[400px]" data-name="Container" style={{ backgroundImage: "linear-gradient(135deg, rgba(190, 219, 255, 0.3) 0%, rgba(233, 212, 255, 0.2) 50%, rgba(0, 0, 0, 0) 100%)" }} />;
}

function Container18() {
  return (
    <div className="absolute content-stretch flex h-[1093.891px] items-center justify-center left-0 top-0 w-[489.5px]" data-name="Container">
      <Container19 />
    </div>
  );
}

function ImageReHSscmDevice() {
  return (
    <div className="absolute h-[820.418px] left-[61.19px] shadow-[0px_25px_50px_0px_rgba(0,0,0,0.15)] top-[136.74px] w-[367.125px]" data-name="Image (re:H SSCM Device)">
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImageReHSscmDevice} />
    </div>
  );
}

function Container20() {
  return (
    <div className="absolute h-[1093.891px] left-0 top-0 w-[489.5px]" data-name="Container">
      <ImageReHSscmDevice />
    </div>
  );
}

function Container17() {
  return (
    <div className="absolute h-[1093.891px] left-[585.5px] top-0 w-[489.5px]" data-name="Container">
      <Container18 />
      <Container20 />
    </div>
  );
}

function Container3() {
  return (
    <div className="absolute h-[1093.891px] left-[48px] top-[96px] w-[1075px]" data-name="Container">
      <Container4 />
      <Container17 />
    </div>
  );
}

function Hero() {
  return (
    <div className="bg-gradient-to-b from-white h-[1122px] overflow-clip relative shrink-0 to-white via-1/2 via-[#f9fafb] w-full" data-name="Hero">
      <Container />
      <Container1 />
      <Container2 />
      <Container3 />
    </div>
  );
}

function Heading1() {
  return (
    <div className="absolute h-[48px] left-0 top-0 w-[1107px]" data-name="Heading 2">
      <p className="-translate-x-1/2 absolute font-['Inter:Bold',sans-serif] font-bold leading-[48px] left-[553.16px] not-italic text-[#101828] text-[48px] text-center top-px tracking-[-0.1284px]">What Makes SSCM™ Different?</p>
    </div>
  );
}

function Paragraph4() {
  return (
    <div className="absolute h-[56px] left-[217.5px] top-[64px] w-[672px]" data-name="Paragraph">
      <p className="-translate-x-1/2 absolute font-['Inter:Regular',sans-serif] font-normal leading-[28px] left-[336.38px] not-italic text-[#4a5565] text-[18px] text-center top-0 tracking-[-0.4395px] w-[629px] whitespace-pre-wrap">Engineering-level precision with patented air subcision technology for superior clinical outcomes</p>
    </div>
  );
}

function Container22() {
  return (
    <div className="h-[120px] relative shrink-0 w-full" data-name="Container">
      <Heading1 />
      <Paragraph4 />
    </div>
  );
}

function Heading2() {
  return (
    <div className="h-[20px] relative shrink-0 w-[103.984px]" data-name="Heading 3">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[20px] left-0 not-italic text-[#101828] text-[14px] top-0 tracking-[0.5496px] uppercase">Comparison</p>
      </div>
    </div>
  );
}

function Container26() {
  return (
    <div className="content-stretch flex h-[48px] items-center relative shrink-0 w-full" data-name="Container">
      <Heading2 />
    </div>
  );
}

function Container28() {
  return (
    <div className="content-stretch flex h-[48px] items-center relative shrink-0 w-full" data-name="Container">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[20px] not-italic relative shrink-0 text-[#364153] text-[14px] tracking-[-0.1504px]">Depth Control</p>
    </div>
  );
}

function Container29() {
  return (
    <div className="content-stretch flex h-[48px] items-center relative shrink-0 w-full" data-name="Container">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[20px] not-italic relative shrink-0 text-[#364153] text-[14px] tracking-[-0.1504px]">Accuracy</p>
    </div>
  );
}

function Container30() {
  return (
    <div className="content-stretch flex h-[48px] items-center relative shrink-0 w-full" data-name="Container">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[20px] not-italic relative shrink-0 text-[#364153] text-[14px] tracking-[-0.1504px]">Drug Delivery</p>
    </div>
  );
}

function Container31() {
  return (
    <div className="content-stretch flex h-[48px] items-center relative shrink-0 w-full" data-name="Container">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[20px] not-italic relative shrink-0 text-[#364153] text-[14px] tracking-[-0.1504px]">Safety System</p>
    </div>
  );
}

function Container32() {
  return (
    <div className="content-stretch flex h-[48px] items-center relative shrink-0 w-full" data-name="Container">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[20px] not-italic relative shrink-0 text-[#364153] text-[14px] tracking-[-0.1504px]">Treatment Time</p>
    </div>
  );
}

function Container27() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] h-[304px] items-start relative shrink-0 w-full" data-name="Container">
      <Container28 />
      <Container29 />
      <Container30 />
      <Container31 />
      <Container32 />
    </div>
  );
}

function Container25() {
  return (
    <div className="col-1 justify-self-stretch relative row-1 self-stretch shrink-0" data-name="Container" style={{ backgroundImage: "linear-gradient(123.086deg, rgb(249, 250, 251) 0%, rgb(243, 244, 246) 100%)" }}>
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-r border-solid inset-0 pointer-events-none" />
      <div className="content-stretch flex flex-col gap-[24px] items-start pl-[24px] pr-[25px] pt-[24px] relative size-full">
        <Container26 />
        <Container27 />
      </div>
    </div>
  );
}

function Icon1() {
  return (
    <div className="absolute left-[24.89px] size-[24px] top-0" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <path d={svgPaths.pace200} id="Vector" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d="M12 8V12" id="Vector_2" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d="M12 16H12.01" id="Vector_3" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Heading3() {
  return (
    <div className="absolute h-[20px] left-0 top-[32px] w-[73.797px]" data-name="Heading 4">
      <p className="-translate-x-1/2 absolute font-['Inter:Bold',sans-serif] font-bold leading-[20px] left-[37px] not-italic text-[#101828] text-[14px] text-center top-0 tracking-[-0.1504px]">Traditional</p>
    </div>
  );
}

function Container35() {
  return (
    <div className="h-[52px] relative shrink-0 w-[73.797px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon1 />
        <Heading3 />
      </div>
    </div>
  );
}

function Container34() {
  return (
    <div className="h-[48px] relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center justify-center size-full">
        <div className="content-stretch flex items-center justify-center pr-[0.016px] relative size-full">
          <Container35 />
        </div>
      </div>
    </div>
  );
}

function Container37() {
  return (
    <div className="content-stretch flex h-[48px] items-center relative shrink-0 w-full" data-name="Container">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#4a5565] text-[14px] tracking-[-0.1504px]">Manual adjustment</p>
    </div>
  );
}

function Container38() {
  return (
    <div className="content-stretch flex h-[48px] items-center relative shrink-0 w-full" data-name="Container">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#4a5565] text-[14px] tracking-[-0.1504px]">±0.1–0.2mm variance</p>
    </div>
  );
}

function Container39() {
  return (
    <div className="content-stretch flex h-[48px] items-center relative shrink-0 w-full" data-name="Container">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#4a5565] text-[14px] tracking-[-0.1504px]">Topical absorption</p>
    </div>
  );
}

function Container40() {
  return (
    <div className="content-stretch flex h-[48px] items-center relative shrink-0 w-full" data-name="Container">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#4a5565] text-[14px] tracking-[-0.1504px]">Basic sensors</p>
    </div>
  );
}

function Container41() {
  return (
    <div className="content-stretch flex h-[48px] items-center relative shrink-0 w-full" data-name="Container">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#4a5565] text-[14px] tracking-[-0.1504px]">15-20 min</p>
    </div>
  );
}

function Container36() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] h-[304px] items-start relative shrink-0 w-full" data-name="Container">
      <Container37 />
      <Container38 />
      <Container39 />
      <Container40 />
      <Container41 />
    </div>
  );
}

function Container33() {
  return (
    <div className="bg-white col-2 justify-self-stretch relative row-1 self-stretch shrink-0" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-r border-solid inset-0 pointer-events-none" />
      <div className="content-stretch flex flex-col gap-[24px] items-start pl-[24px] pr-[25px] pt-[24px] relative size-full">
        <Container34 />
        <Container36 />
      </div>
    </div>
  );
}

function Icon2() {
  return (
    <div className="absolute left-[22.78px] size-[24px] top-0" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <path d={svgPaths.p6428280} id="Vector" stroke="var(--stroke-0, #FF6900)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Heading4() {
  return (
    <div className="absolute h-[20px] left-0 top-[32px] w-[69.578px]" data-name="Heading 4">
      <p className="-translate-x-1/2 absolute font-['Inter:Bold',sans-serif] font-bold leading-[20px] left-[35px] not-italic text-[#101828] text-[14px] text-center top-0 tracking-[-0.1504px]">RF Energy</p>
    </div>
  );
}

function Container44() {
  return (
    <div className="h-[52px] relative shrink-0 w-[69.578px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon2 />
        <Heading4 />
      </div>
    </div>
  );
}

function Container43() {
  return (
    <div className="h-[48px] relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center justify-center size-full">
        <div className="content-stretch flex items-center justify-center pr-[0.016px] relative size-full">
          <Container44 />
        </div>
      </div>
    </div>
  );
}

function Container46() {
  return (
    <div className="content-stretch flex h-[48px] items-center relative shrink-0 w-full" data-name="Container">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#4a5565] text-[14px] tracking-[-0.1504px]">Semi-automatic</p>
    </div>
  );
}

function Container47() {
  return (
    <div className="content-stretch flex h-[48px] items-center relative shrink-0 w-full" data-name="Container">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#4a5565] text-[14px] tracking-[-0.1504px]">±0.05mm variance</p>
    </div>
  );
}

function Container48() {
  return (
    <div className="content-stretch flex h-[48px] items-center relative shrink-0 w-full" data-name="Container">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#4a5565] text-[14px] tracking-[-0.1504px]">Heat + channels</p>
    </div>
  );
}

function Container49() {
  return (
    <div className="content-stretch flex h-[48px] items-center relative shrink-0 w-full" data-name="Container">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#4a5565] text-[14px] tracking-[-0.1504px]">Thermal monitoring</p>
    </div>
  );
}

function Container50() {
  return (
    <div className="content-stretch flex h-[48px] items-center relative shrink-0 w-full" data-name="Container">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#4a5565] text-[14px] tracking-[-0.1504px]">12-15 min</p>
    </div>
  );
}

function Container45() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] h-[304px] items-start relative shrink-0 w-full" data-name="Container">
      <Container46 />
      <Container47 />
      <Container48 />
      <Container49 />
      <Container50 />
    </div>
  );
}

function Container42() {
  return (
    <div className="bg-[rgba(255,247,237,0.5)] col-3 justify-self-stretch relative row-1 self-stretch shrink-0" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-r border-solid inset-0 pointer-events-none" />
      <div className="content-stretch flex flex-col gap-[24px] items-start pl-[24px] pr-[25px] pt-[24px] relative size-full">
        <Container43 />
        <Container45 />
      </div>
    </div>
  );
}

function Icon3() {
  return (
    <div className="absolute left-[31.45px] size-[24px] top-0" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <path d={svgPaths.p1b8b3180} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Heading5() {
  return (
    <div className="absolute h-[20px] left-0 top-[32px] w-[86.906px]" data-name="Heading 4">
      <p className="-translate-x-1/2 absolute font-['Inter:Bold',sans-serif] font-bold leading-[20px] left-[43.5px] not-italic text-[20px] text-center text-white top-0 tracking-[-0.1504px]">re:H SSCM™</p>
    </div>
  );
}

function Container53() {
  return (
    <div className="h-[52px] relative shrink-0 w-[86.906px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon3 />
        <Heading5 />
      </div>
    </div>
  );
}

function Container52() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0 w-full" data-name="Container">
      <Container53 />
    </div>
  );
}

function Container55() {
  return (
    <div className="content-stretch flex h-[48px] items-center relative shrink-0 w-full" data-name="Container">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[20px] not-italic relative shrink-0 text-[#eff6ff] text-[20px] tracking-[-0.1504px]">✓ Digital ±0.01mm</p>
    </div>
  );
}

function Container56() {
  return (
    <div className="content-stretch flex h-[48px] items-center relative shrink-0 w-full" data-name="Container">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[20px] not-italic relative shrink-0 text-[#eff6ff] text-[20px] tracking-[-0.1504px]">✓ 99.7% precision</p>
    </div>
  );
}

function Container57() {
  return (
    <div className="content-stretch flex h-[48px] items-center relative shrink-0 w-full" data-name="Container">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[0] not-italic relative shrink-0 text-[#eff6ff] text-[0px] tracking-[-0.1504px]">
        <span className="leading-[20px] text-[20px]">{`✓ `}</span>
        <span className="leading-[20px] text-[16px]">Air subcision + Drug Delivery</span>
      </p>
    </div>
  );
}

function Container58() {
  return (
    <div className="content-stretch flex h-[48px] items-center relative shrink-0 w-full" data-name="Container">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[20px] not-italic relative shrink-0 text-[#eff6ff] text-[20px] tracking-[-0.1504px]">✓ 13-point array</p>
    </div>
  );
}

function Container59() {
  return (
    <div className="content-stretch flex h-[48px] items-center relative shrink-0 w-full" data-name="Container">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[20px] not-italic relative shrink-0 text-[#eff6ff] text-[20px] tracking-[-0.1504px]">✓ ~15 min (3,000 shots)</p>
    </div>
  );
}

function Container54() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] h-[304px] items-start relative shrink-0 w-full" data-name="Container">
      <Container55 />
      <Container56 />
      <Container57 />
      <Container58 />
      <Container59 />
    </div>
  );
}

function Container51() {
  return (
    <div className="col-4 justify-self-stretch relative row-1 self-stretch shrink-0" data-name="Container" style={{ backgroundImage: "linear-gradient(123.086deg, rgb(21, 93, 252) 0%, rgb(20, 71, 230) 100%)" }}>
      <div className="content-stretch flex flex-col gap-[24px] items-start pt-[24px] px-[24px] relative size-full">
        <Container52 />
        <Container54 />
      </div>
    </div>
  );
}

function Container24() {
  return (
    <div className="grid grid-cols-[repeat(4,minmax(0,1fr))] grid-rows-[repeat(1,minmax(0,1fr))] h-[424px] relative shrink-0 w-full" data-name="Container">
      <Container25 />
      <Container33 />
      <Container42 />
      <Container51 />
    </div>
  );
}

function Container23() {
  return (
    <div className="bg-white h-[426px] relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col items-start p-px relative size-full">
          <Container24 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#e5e7eb] border-solid inset-0 pointer-events-none rounded-[16px] shadow-[0px_20px_25px_-5px_rgba(0,0,0,0.1),0px_8px_10px_-6px_rgba(0,0,0,0.1)]" />
    </div>
  );
}

function Icon4() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g clipPath="url(#clip0_1_949)" id="Icon">
          <path d={svgPaths.p14d24500} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p240d7000} id="Vector_2" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p25499600} id="Vector_3" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
        <defs>
          <clipPath id="clip0_1_949">
            <rect fill="white" height="20" width="20" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container62() {
  return (
    <div className="absolute bg-[#dbeafe] content-stretch flex items-center justify-center left-[26px] rounded-[10px] size-[40px] top-[26px]" data-name="Container">
      <Icon4 />
    </div>
  );
}

function Heading6() {
  return <div className="absolute h-[24px] left-[26px] top-[82px] w-[301px]" data-name="Heading 4" />;
}

function Text7() {
  return <div className="absolute h-[17px] left-0 top-[2px] w-[87.297px]" data-name="Text" />;
}

function Paragraph5() {
  return (
    <div className="absolute h-[91px] left-[26px] top-[114px] w-[301px]" data-name="Paragraph">
      <Text7 />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[0] left-px not-italic text-[#4a5565] text-[0px] text-[16px] top-[-20px] tracking-[-0.1504px] w-[300px] whitespace-pre-wrap">
        <span className="font-['Inter:Bold',sans-serif] font-bold leading-[22.75px] text-[#1447e6]">Air subcision</span>
        <span className="font-['Inter:Bold',sans-serif] font-bold leading-[22.75px]">{` `}</span>
        <span className="leading-[22.75px]">creates pneumatic pressure between dermis layers, mechanically releasing fibrotic bands and lifting atrophic scars from beneath without thermal damage.</span>
      </p>
    </div>
  );
}

function Container61() {
  return (
    <div className="bg-white col-1 justify-self-stretch relative rounded-[14px] row-1 self-stretch shrink-0" data-name="Container">
      <div aria-hidden="true" className="absolute border-2 border-[#e5e7eb] border-solid inset-0 pointer-events-none rounded-[14px]" />
      <Container62 />
      <Heading6 />
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold h-[36px] leading-[24px] left-[84px] not-italic text-[#101828] text-[32px] top-[30px] tracking-[-0.3125px] w-[211px] whitespace-pre-wrap">Acne Scars</p>
      <Paragraph5 />
    </div>
  );
}

function Icon5() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p3161fe80} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Container64() {
  return (
    <div className="absolute bg-[#dbeafe] content-stretch flex items-center justify-center left-[26px] rounded-[10px] size-[40px] top-[26px]" data-name="Container">
      <Icon5 />
    </div>
  );
}

function Heading7() {
  return <div className="absolute h-[24px] left-[26px] top-[82px] w-[301px]" data-name="Heading 4" />;
}

function Paragraph6() {
  return (
    <div className="absolute h-[91px] left-[26px] top-[94px] w-[301px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[0] left-0 not-italic text-[#4a5565] text-[0px] text-[16px] top-0 tracking-[-0.1504px] w-[323px] whitespace-pre-wrap">
        <span className="leading-[22.75px]">{`Positive pressure delivery stimulates `}</span>
        <span className="font-['Inter:Bold',sans-serif] font-bold leading-[22.75px] text-[#1447e6]">sebaceous gland remodeling</span>
        <span className="font-['Inter:Bold',sans-serif] font-bold leading-[22.75px]">{` `}</span>
        <span className="leading-[22.75px]">and collagen compaction around pore structures, reducing diameter by 40-45% without ablative injury.</span>
      </p>
    </div>
  );
}

function Container63() {
  return (
    <div className="bg-white col-2 justify-self-stretch relative rounded-[14px] row-1 self-stretch shrink-0" data-name="Container">
      <div aria-hidden="true" className="absolute border-2 border-[#e5e7eb] border-solid inset-0 pointer-events-none rounded-[14px]" />
      <Container64 />
      <Heading7 />
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[24px] left-[72px] not-italic text-[#101828] text-[32px] top-[32px] tracking-[-0.3125px]">Pore Refinement</p>
      <Paragraph6 />
    </div>
  );
}

function Icon6() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p2898e700} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Container66() {
  return (
    <div className="absolute bg-[#dbeafe] content-stretch flex items-center justify-center left-[26px] rounded-[10px] size-[40px] top-[26px]" data-name="Container">
      <Icon6 />
    </div>
  );
}

function Heading8() {
  return <div className="absolute h-[24px] left-[26px] top-[82px] w-[301px]" data-name="Heading 4" />;
}

function Text8() {
  return (
    <div className="absolute content-stretch flex h-[89px] items-start left-0 top-[-18px] w-[301px]" data-name="Text">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold h-[89px] leading-[0] not-italic relative shrink-0 text-[#155dfc] text-[0px] text-[16px] tracking-[-0.1504px] w-[301px] whitespace-pre-wrap">
        <span className="leading-[22.75px]">{`Controlled microchannel injection `}</span>
        <span className="leading-[22.75px] text-[#4a5565]">{` `}</span>
        <span className="font-['Inter:Regular',sans-serif] font-normal leading-[22.75px] text-[#4a5565]">delivers tyrosinase inhibitors directly to melanocyte clusters at DEJ (0.5-0.8mm), achieving 400% higher absorption vs topical application.</span>
      </p>
    </div>
  );
}

function Paragraph7() {
  return (
    <div className="absolute h-[91px] left-[26px] top-[114px] w-[301px]" data-name="Paragraph">
      <Text8 />
    </div>
  );
}

function Container65() {
  return (
    <div className="bg-white col-3 justify-self-stretch relative rounded-[14px] row-1 self-stretch shrink-0" data-name="Container">
      <div aria-hidden="true" className="absolute border-2 border-[#e5e7eb] border-solid inset-0 pointer-events-none rounded-[14px]" />
      <Container66 />
      <Heading8 />
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[24px] left-[73px] not-italic text-[#101828] text-[32px] top-[32px] tracking-[-0.3125px]">Pigmentation</p>
      <Paragraph7 />
    </div>
  );
}

function Container60() {
  return (
    <div className="gap-x-[24px] gap-y-[24px] grid grid-cols-[repeat(3,minmax(0,1fr))] grid-rows-[repeat(1,minmax(0,1fr))] h-[231px] relative shrink-0 w-full" data-name="Container">
      <Container61 />
      <Container63 />
      <Container65 />
    </div>
  );
}

function ImageBalloonTipTechnology() {
  return (
    <div className="h-[279px] relative shrink-0 w-[216px]" data-name="Image (Balloon Tip Technology)">
      <div className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 overflow-hidden pointer-events-none">
        <img alt="" className="absolute h-[99.87%] left-[0.04%] max-w-none top-[0.04%] w-[105.24%]" src={imgImageBalloonTipTechnology} />
      </div>
    </div>
  );
}

function Container69() {
  return (
    <div className="h-[279px] relative shrink-0 w-[215.797px]" data-name="Container" style={{ backgroundImage: "linear-gradient(127.721deg, rgb(239, 246, 255) 0%, rgb(249, 250, 251) 100%)" }}>
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <ImageBalloonTipTechnology />
      </div>
    </div>
  );
}

function Container72() {
  return <div className="bg-[#155dfc] rounded-[33554400px] shrink-0 size-[8px]" data-name="Container" />;
}

function Heading9() {
  return (
    <div className="h-[28px] relative shrink-0 w-[120.969px]" data-name="Heading 4">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[28px] left-0 not-italic text-[#101828] text-[20px] top-0 tracking-[-0.4492px]">Balloon Tip™</p>
      </div>
    </div>
  );
}

function Container71() {
  return (
    <div className="content-stretch flex gap-[8px] h-[28px] items-center relative shrink-0 w-full" data-name="Container">
      <Container72 />
      <Heading9 />
    </div>
  );
}

function Paragraph8() {
  return (
    <div className="h-[91px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[22.75px] left-[-0.8px] not-italic text-[#4a5565] text-[14px] top-0 tracking-[-0.1504px] w-[295px] whitespace-pre-wrap">Patented pressure control creates micro-subcision and delivers concentrated solution, facilitating absorption of surface-applied compounds to intended dermal depths.</p>
    </div>
  );
}

function Container75() {
  return (
    <div className="content-stretch flex h-[16px] items-start relative shrink-0 w-full" data-name="Container">
      <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[16px] min-h-px min-w-px not-italic relative text-[#6a7282] text-[12px] whitespace-pre-wrap">Needle</p>
    </div>
  );
}

function Container76() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[24px] left-0 not-italic text-[#101828] text-[20px] top-0 tracking-[-0.3125px]">13 pin</p>
    </div>
  );
}

function Container74() {
  return (
    <div className="absolute bg-[#f9fafb] content-stretch flex flex-col gap-[4px] h-[84px] items-start left-0 pt-[8px] px-[12px] rounded-[10px] top-0 w-[131.844px]" data-name="Container">
      <Container75 />
      <Container76 />
    </div>
  );
}

function Container78() {
  return (
    <div className="content-stretch flex h-[16px] items-start relative shrink-0 w-full" data-name="Container">
      <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[16px] min-h-px min-w-px not-italic relative text-[#6a7282] text-[12px] whitespace-pre-wrap">Depth</p>
    </div>
  );
}

function Container79() {
  return (
    <div className="h-[48px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[24px] left-0 not-italic text-[#101828] text-[16px] top-0 tracking-[-0.3125px] w-[66px] whitespace-pre-wrap">0.25–4.00mm</p>
    </div>
  );
}

function Container77() {
  return (
    <div className="absolute bg-[#f9fafb] content-stretch flex flex-col gap-[4px] h-[84px] items-start left-[143.84px] pt-[8px] px-[12px] rounded-[10px] top-0 w-[131.844px]" data-name="Container">
      <Container78 />
      <Container79 />
    </div>
  );
}

function Container73() {
  return (
    <div className="h-[84px] relative shrink-0 w-full" data-name="Container">
      <Container74 />
      <Container77 />
    </div>
  );
}

function Container70() {
  return (
    <div className="h-[279px] relative shrink-0 w-[323.688px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[12px] items-start pt-[24px] px-[24px] relative size-full">
        <Container71 />
        <Paragraph8 />
        <Container73 />
      </div>
    </div>
  );
}

function Container68() {
  return (
    <div className="bg-white col-1 justify-self-stretch relative rounded-[14px] row-1 self-stretch shrink-0" data-name="Container">
      <div className="content-stretch flex items-start overflow-clip p-px relative rounded-[inherit] size-full">
        <Container69 />
        <Container70 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#e5e7eb] border-solid inset-0 pointer-events-none rounded-[14px] shadow-[0px_10px_15px_-3px_rgba(0,0,0,0.1),0px_4px_6px_-4px_rgba(0,0,0,0.1)]" />
    </div>
  );
}

function ImageBlowTipTechnology() {
  return (
    <div className="h-[279px] relative shrink-0 w-[215px]" data-name="Image (Blow Tip Technology)">
      <div className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 overflow-hidden pointer-events-none">
        <img alt="" className="absolute h-[99.91%] left-[-8.16%] max-w-none top-0 w-[123.36%]" src={imgImageBlowTipTechnology} />
      </div>
    </div>
  );
}

function Container81() {
  return (
    <div className="h-[279px] relative shrink-0 w-[215.797px]" data-name="Container" style={{ backgroundImage: "linear-gradient(127.721deg, rgb(239, 246, 255) 0%, rgb(249, 250, 251) 100%)" }}>
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <ImageBlowTipTechnology />
      </div>
    </div>
  );
}

function Container84() {
  return <div className="bg-[#155dfc] rounded-[33554400px] shrink-0 size-[8px]" data-name="Container" />;
}

function Heading10() {
  return (
    <div className="h-[28px] relative shrink-0 w-[96.922px]" data-name="Heading 4">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[28px] left-0 not-italic text-[#101828] text-[20px] top-0 tracking-[-0.4492px]">Blow Tip™</p>
      </div>
    </div>
  );
}

function Container83() {
  return (
    <div className="content-stretch flex gap-[8px] h-[28px] items-center relative shrink-0 w-full" data-name="Container">
      <Container84 />
      <Heading10 />
    </div>
  );
}

function Paragraph9() {
  return (
    <div className="h-[91px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[22.75px] left-0 not-italic text-[#4a5565] text-[14px] top-0 tracking-[-0.1504px] w-[247px] whitespace-pre-wrap">Positive pressure generation during needle retraction delivers compounds uniformly across treatment zones with precision air subcision effect.</p>
    </div>
  );
}

function Container87() {
  return (
    <div className="content-stretch flex h-[16px] items-start relative shrink-0 w-full" data-name="Container">
      <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[16px] min-h-px min-w-px not-italic relative text-[#6a7282] text-[12px] whitespace-pre-wrap">Needle</p>
    </div>
  );
}

function Container88() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[24px] left-0 not-italic text-[#101828] text-[20px] top-0 tracking-[-0.3125px]">16 pin</p>
    </div>
  );
}

function Container86() {
  return (
    <div className="absolute bg-[#f9fafb] content-stretch flex flex-col gap-[4px] h-[84px] items-start left-0 pt-[8px] px-[12px] rounded-[10px] top-0 w-[131.844px]" data-name="Container">
      <Container87 />
      <Container88 />
    </div>
  );
}

function Container90() {
  return (
    <div className="content-stretch flex h-[16px] items-start relative shrink-0 w-full" data-name="Container">
      <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[16px] min-h-px min-w-px not-italic relative text-[#6a7282] text-[12px] whitespace-pre-wrap">Depth</p>
    </div>
  );
}

function Container91() {
  return (
    <div className="h-[48px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[24px] left-0 not-italic text-[#101828] text-[16px] top-0 tracking-[-0.3125px] w-[66px] whitespace-pre-wrap">0.25–4.00mm</p>
    </div>
  );
}

function Container89() {
  return (
    <div className="absolute bg-[#f9fafb] content-stretch flex flex-col gap-[4px] h-[84px] items-start left-[143.84px] pt-[8px] px-[12px] rounded-[10px] top-0 w-[131.844px]" data-name="Container">
      <Container90 />
      <Container91 />
    </div>
  );
}

function Container85() {
  return (
    <div className="h-[84px] relative shrink-0 w-full" data-name="Container">
      <Container86 />
      <Container89 />
    </div>
  );
}

function Container82() {
  return (
    <div className="h-[279px] relative shrink-0 w-[323.688px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[12px] items-start pt-[24px] px-[24px] relative size-full">
        <Container83 />
        <Paragraph9 />
        <Container85 />
      </div>
    </div>
  );
}

function Container80() {
  return (
    <div className="bg-white col-2 justify-self-stretch relative rounded-[14px] row-1 self-stretch shrink-0" data-name="Container">
      <div className="content-stretch flex items-start overflow-clip p-px relative rounded-[inherit] size-full">
        <Container81 />
        <Container82 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#e5e7eb] border-solid inset-0 pointer-events-none rounded-[14px] shadow-[0px_10px_15px_-3px_rgba(0,0,0,0.1),0px_4px_6px_-4px_rgba(0,0,0,0.1)]" />
    </div>
  );
}

function Container67() {
  return (
    <div className="gap-x-[24px] gap-y-[24px] grid grid-cols-[repeat(2,minmax(0,1fr))] grid-rows-[repeat(1,minmax(0,1fr))] h-[281px] relative shrink-0 w-full" data-name="Container">
      <Container68 />
      <Container80 />
    </div>
  );
}

function Icon7() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.pa28c500} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Container94() {
  return (
    <div className="bg-[#155dfc] relative rounded-[33554400px] shrink-0 size-[40px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon7 />
      </div>
    </div>
  );
}

function Heading11() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Heading 4">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[24px] left-0 not-italic text-[#101828] text-[16px] top-0 tracking-[-0.3125px]">Patented Korean Technology (KR 10-2604809, KR 10-2669940)</p>
    </div>
  );
}

function Paragraph10() {
  return (
    <div className="h-[45.5px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[22.75px] left-0 not-italic text-[#4a5565] text-[14px] top-0 tracking-[-0.1504px] w-[937px] whitespace-pre-wrap">SSCM™ combines Balloon Tip™ and Blow Tip™ with Stacking Mode (up to 3 depths per shot) to deliver microneedling elevated to medical-device precision—supporting well-balanced treatments for optimal clinical outcomes.</p>
    </div>
  );
}

function Container95() {
  return (
    <div className="flex-[1_0_0] h-[77.5px] min-h-px min-w-px relative" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[8px] items-start relative size-full">
        <Heading11 />
        <Paragraph10 />
      </div>
    </div>
  );
}

function Container93() {
  return (
    <div className="content-stretch flex gap-[16px] h-[77.5px] items-start relative shrink-0 w-full" data-name="Container">
      <Container94 />
      <Container95 />
    </div>
  );
}

function Container92() {
  return (
    <div className="bg-[#eff6ff] h-[125.5px] relative rounded-br-[10px] rounded-tr-[10px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#155dfc] border-l-4 border-solid inset-0 pointer-events-none rounded-br-[10px] rounded-tr-[10px]" />
      <div className="content-stretch flex flex-col items-start pl-[28px] pr-[24px] pt-[24px] relative size-full">
        <Container93 />
      </div>
    </div>
  );
}

function Container21() {
  return (
    <div className="h-[1335.5px] relative shrink-0 w-full" data-name="Container">
      <div className="content-stretch flex flex-col gap-[40px] items-start px-[32px] relative size-full">
        <Container22 />
        <Container23 />
        <Container60 />
        <Container67 />
        <Container92 />
      </div>
    </div>
  );
}

function WhatIsSscm() {
  return (
    <div className="bg-gradient-to-b content-stretch flex flex-col from-white h-[1458px] items-start overflow-clip pt-[64px] relative shrink-0 to-white via-1/2 via-[#f9fafb] w-full" data-name="WhatIsSSCM">
      <Container21 />
    </div>
  );
}

function Container96() {
  return <div className="absolute h-[925px] left-0 opacity-2 top-[51.5px] w-[1171px]" data-name="Container" style={{ backgroundImage: "url(\'data:image/svg+xml;utf8,<svg viewBox=\\'0 0 1171 925\\' xmlns=\\'http://www.w3.org/2000/svg\\' preserveAspectRatio=\\'none\\'><rect x=\\'0\\' y=\\'0\\' height=\\'100%\\' width=\\'100%\\' fill=\\'url(%23grad)\\' opacity=\\'1\\'/><defs><radialGradient id=\\'grad\\' gradientUnits=\\'userSpaceOnUse\\' cx=\\'0\\' cy=\\'0\\' r=\\'10\\' gradientTransform=\\'matrix(0 -62.792 -86.564 0 585.5 462.5)\\'><stop stop-color=\\'rgba(10,10,10,1)\\' offset=\\'0.00085397\\'/><stop stop-color=\\'rgba(0,0,0,0)\\' offset=\\'0\\'/></radialGradient></defs></svg>\')" }} />;
}

function Container97() {
  return <div className="absolute blur-[64px] left-[292.75px] rounded-[33554400px] size-[500px] top-[318.8px]" data-name="Container" style={{ backgroundImage: "linear-gradient(135deg, rgba(239, 246, 255, 0.4) 0%, rgba(0, 0, 0, 0) 100%)" }} />;
}

function Container101() {
  return <div className="absolute bg-[#fb2c36] left-[20px] opacity-79 rounded-[33554400px] size-[8px] top-[14px]" data-name="Container" />;
}

function Text9() {
  return (
    <div className="absolute content-stretch flex h-[16px] items-start left-[40px] top-[10px] w-[263.969px]" data-name="Text">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#364153] text-[12px] text-center tracking-[1.8px] uppercase">Official Technology Showcase</p>
    </div>
  );
}

function Container100() {
  return (
    <div className="absolute bg-[rgba(255,255,255,0.6)] border border-[#e5e7eb] border-solid h-[38px] left-[374.52px] rounded-[33554400px] top-0 w-[325.969px]" data-name="Container">
      <Container101 />
      <Text9 />
    </div>
  );
}

function Text10() {
  return (
    <div className="absolute content-stretch flex h-[71px] items-start left-[684px] top-0 w-[227.531px]" data-name="Text">
      <p className="bg-clip-text font-['Inter:Bold',sans-serif] font-bold leading-[66px] not-italic relative shrink-0 text-[60px] text-[rgba(0,0,0,0)] text-center tracking-[-1.2363px]" style={{ backgroundImage: "linear-gradient(90deg, rgba(0, 0, 0, 0) 0%, rgba(0, 0, 0, 0) 100%), linear-gradient(rgb(30, 64, 175) 0%, rgb(59, 130, 246) 50%, rgb(96, 165, 250) 100%)", WebkitTextFillColor: "transparent" }}>
        in Action
      </p>
    </div>
  );
}

function Heading12() {
  return (
    <div className="absolute h-[132px] left-0 top-[62px] w-[1075px]" data-name="Heading 2">
      <p className="-translate-x-1/2 absolute font-['Inter:Bold',sans-serif] font-bold leading-[66px] left-[409px] not-italic text-[#0a0a0a] text-[60px] text-center top-0 tracking-[-1.2363px]">SSCM Technology</p>
      <Text10 />
    </div>
  );
}

function Container99() {
  return (
    <div className="absolute h-[209px] left-[48px] top-0 w-[1075px]" data-name="Container">
      <Container100 />
      <Heading12 />
    </div>
  );
}

function Container105() {
  return <div className="h-[602.688px] opacity-10 shrink-0 w-full" data-name="Container" style={{ backgroundImage: "linear-gradient(rgba(255, 255, 255, 0.05) 0.16592%, rgba(0, 0, 0, 0) 0.16592%), linear-gradient(90deg, rgba(255, 255, 255, 0.05) 0%, rgba(0, 0, 0, 0) 0%)" }} />;
}

function Container104() {
  return (
    <div className="absolute content-stretch flex flex-col h-[602.688px] items-start left-px top-px w-[1073px]" data-name="Container" style={{ backgroundImage: "linear-gradient(150.678deg, rgba(21, 93, 252, 0.3) 0%, rgba(0, 0, 0, 0) 50%, rgba(15, 23, 43, 0.6) 100%)" }}>
      <Container105 />
    </div>
  );
}

function Icon8() {
  return (
    <div className="relative shrink-0 size-[44px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 44 44">
        <g id="Icon">
          <path d={svgPaths.p1fe29b00} fill="var(--fill-0, #0A0A0A)" id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="3.66667" />
        </g>
      </svg>
    </div>
  );
}

function Container107() {
  return (
    <div className="absolute bg-white content-stretch flex items-center justify-center left-0 pl-[8px] rounded-[33554400px] shadow-[0px_25px_50px_0px_rgba(0,0,0,0.25)] size-[112px] top-0" data-name="Container">
      <Icon8 />
    </div>
  );
}

function Container108() {
  return <div className="absolute bg-white left-[-50.37px] opacity-2 rounded-[33554400px] size-[212.746px] top-[-50.37px]" data-name="Container" />;
}

function Container109() {
  return <div className="bg-[rgba(255,255,255,0.3)] opacity-79 rounded-[33554400px] size-[160px]" data-name="Container" />;
}

function Button2() {
  return (
    <div className="absolute left-[480.5px] size-[112px] top-[245.34px]" data-name="Button">
      <Container107 />
      <Container108 />
      <div className="absolute flex items-center justify-center left-[-24.2px] size-[160.409px] top-[-24.2px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-[-0.15deg]">
          <Container109 />
        </div>
      </div>
    </div>
  );
}

function Container106() {
  return (
    <div className="absolute h-[602.688px] left-px top-px w-[1073px]" data-name="Container">
      <Button2 />
      <div className="absolute h-[611px] left-[-1px] top-[0.5px] w-[1086px]" data-name="reh full 1">
        <video autoPlay className="absolute max-w-none object-cover size-full" controlsList="nodownload" loop playsInline>
          <source src="/_videos/v1/f2ec48a5725044e184a2fb1f5e6c398c95bf817b" />
        </video>
      </div>
    </div>
  );
}

function Container113() {
  return (
    <div className="h-[28px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[28px] left-0 not-italic text-[20px] text-white top-0 tracking-[-0.9492px]">re:H</p>
    </div>
  );
}

function Container114() {
  return (
    <div className="content-stretch flex h-[16px] items-start relative shrink-0 w-full" data-name="Container">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#bedbff] text-[12px] tracking-[0.3px]">SSCM Technology</p>
    </div>
  );
}

function Container112() {
  return (
    <div className="bg-[rgba(255,255,255,0.1)] h-[72px] relative rounded-[16px] shrink-0 w-[149.359px]" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[rgba(255,255,255,0.2)] border-solid inset-0 pointer-events-none rounded-[16px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[2px] items-start pb-px pt-[13px] px-[21px] relative size-full">
        <Container113 />
        <Container114 />
      </div>
    </div>
  );
}

function Icon9() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g clipPath="url(#clip0_1_936)" id="Icon">
          <path d={svgPaths.p874e300} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M13.3333 2V4.66667" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M14.6667 3.33333H12" id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M2.66667 11.3333V12.6667" id="Vector_4" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M3.33333 12H2" id="Vector_5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
        <defs>
          <clipPath id="clip0_1_936">
            <rect fill="white" height="16" width="16" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text11() {
  return (
    <div className="flex-[1_0_0] h-[16px] min-h-px min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[16px] not-italic relative shrink-0 text-[12px] text-white tracking-[0.3px]">TFDA Certified</p>
      </div>
    </div>
  );
}

function Container115() {
  return (
    <div className="bg-[rgba(0,201,80,0.95)] h-[32px] relative rounded-[14px] shrink-0 w-[147.141px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center px-[16px] relative size-full">
        <Icon9 />
        <Text11 />
      </div>
    </div>
  );
}

function Container111() {
  return (
    <div className="content-stretch flex h-[72px] items-center justify-between relative shrink-0 w-full" data-name="Container">
      <Container112 />
      <Container115 />
    </div>
  );
}

function Container110() {
  return (
    <div className="absolute bg-gradient-to-b content-stretch flex flex-col from-[rgba(0,0,0,0.6)] h-[136px] items-start left-px pt-[32px] px-[32px] to-[rgba(0,0,0,0)] top-px w-[1073px]" data-name="Container">
      <Container111 />
    </div>
  );
}

function Container103() {
  return (
    <div className="h-[604.688px] relative rounded-[24px] shrink-0 w-full" data-name="Container" style={{ backgroundImage: "linear-gradient(150.642deg, rgb(28, 57, 142) 0%, rgb(15, 23, 43) 50%, rgb(28, 57, 142) 100%)" }}>
      <div className="overflow-clip relative rounded-[inherit] size-full">
        <Container104 />
        <Container106 />
        <Container110 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#e5e7eb] border-solid inset-0 pointer-events-none rounded-[24px] shadow-[0px_25px_50px_-12px_rgba(0,0,0,0.25)]" />
    </div>
  );
}

function Container102() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[48px] top-[153px] w-[1075px]" data-name="Container">
      <Container103 />
    </div>
  );
}

function Container98() {
  return (
    <div className="absolute h-[784px] left-0 top-[34.5px] w-[1171px]" data-name="Container">
      <Container99 />
      <Container102 />
    </div>
  );
}

function OfficialVideo() {
  return (
    <div className="bg-gradient-to-b from-white h-[909px] overflow-clip relative shrink-0 to-white via-[#f9fafb] via-[39.423%] w-full" data-name="OfficialVideo">
      <Container96 />
      <Container97 />
      <Container98 />
    </div>
  );
}

function Icon10() {
  return (
    <div className="absolute left-[16px] size-[16px] top-[10px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p17f48400} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Text12() {
  return (
    <div className="absolute h-[20px] left-[40px] top-[8px] w-[234.891px]" data-name="Text">
      <p className="-translate-x-1/2 absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[20px] left-[117px] not-italic text-[#1447e6] text-[14px] text-center top-0 tracking-[-0.1504px]">Endorsed by Medical Professionals</p>
    </div>
  );
}

function Container118() {
  return (
    <div className="absolute bg-[#eff6ff] border border-[#bedbff] border-solid h-[38px] left-[407.05px] rounded-[33554400px] top-0 w-[292.891px]" data-name="Container">
      <Icon10 />
      <Text12 />
    </div>
  );
}

function Heading13() {
  return (
    <div className="absolute h-[48px] left-0 top-[54px] w-[1107px]" data-name="Heading 2">
      <p className="-translate-x-1/2 absolute font-['Inter:Bold',sans-serif] font-bold leading-[48px] left-[553.98px] not-italic text-[#101828] text-[48px] text-center top-px tracking-[-0.1284px]">{`Trusted by Asia's Leading Aesthetic Experts`}</p>
    </div>
  );
}

function Paragraph11() {
  return (
    <div className="absolute h-[56px] left-[217.5px] top-[118px] w-[672px]" data-name="Paragraph">
      <p className="-translate-x-1/2 absolute font-['Inter:Regular',sans-serif] font-normal leading-[28px] left-[336.33px] not-italic text-[#4a5565] text-[18px] text-center top-0 tracking-[-0.4395px] w-[668px] whitespace-pre-wrap">{`Endorsed by professors and clinical directors across Asia's most respected medical institutions`}</p>
    </div>
  );
}

function Container117() {
  return (
    <div className="h-[174px] relative shrink-0 w-full" data-name="Container">
      <Container118 />
      <Heading13 />
      <Paragraph11 />
    </div>
  );
}

function Icon11() {
  return (
    <div className="h-[48px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[12.5%_12.5%_12.5%_58.33%]" data-name="Vector">
        <div className="absolute inset-[-5.56%_-14.29%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 40">
            <path d={svgPaths.p98a0a70} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[12.5%_58.33%_12.5%_12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.56%_-14.29%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 40">
            <path d={svgPaths.p2ce0db40} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Container121() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[467.5px] opacity-10 size-[48px] top-[26px]" data-name="Container">
      <Icon11 />
    </div>
  );
}

function Paragraph12() {
  return (
    <div className="h-[45.5px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[22.75px] left-0 not-italic text-[#364153] text-[14px] top-0 tracking-[-0.1504px] w-[462px] whitespace-pre-wrap">{`"The ±0.01mm precision gives me absolute control. I can target specific depths with confidence I've never experienced with other devices."`}</p>
    </div>
  );
}

function Icon12() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g clipPath="url(#clip0_1_895)" id="Icon">
          <path d={svgPaths.p37143280} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p1d7f0000} id="Vector_2" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p2b722f80} id="Vector_3" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33333 5H11.6667" id="Vector_4" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33333 8.33333H11.6667" id="Vector_5" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33333 11.6667H11.6667" id="Vector_6" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33333 15H11.6667" id="Vector_7" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
        <defs>
          <clipPath id="clip0_1_895">
            <rect fill="white" height="20" width="20" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container124() {
  return (
    <div className="bg-[#dbeafe] relative rounded-[33554400px] shrink-0 size-[40px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon12 />
      </div>
    </div>
  );
}

function Container126() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[20px] left-0 not-italic text-[#101828] text-[14px] top-0 tracking-[-0.1504px]">Dr. Thanya Techapichetvanich</p>
    </div>
  );
}

function Container127() {
  return (
    <div className="content-stretch flex h-[16px] items-start relative shrink-0 w-full" data-name="Container">
      <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[16px] min-h-px min-w-px not-italic relative text-[#4a5565] text-[12px] whitespace-pre-wrap">Asst. Professor of Dermatology</p>
    </div>
  );
}

function Container128() {
  return (
    <div className="content-stretch flex h-[16px] items-start relative shrink-0 w-full" data-name="Container">
      <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[16px] min-h-px min-w-px not-italic relative text-[#155dfc] text-[12px] whitespace-pre-wrap">Siriraj Hospital, Bangkok</p>
    </div>
  );
}

function Container125() {
  return (
    <div className="flex-[1_0_0] h-[56px] min-h-px min-w-px relative" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Container126 />
        <Container127 />
        <Container128 />
      </div>
    </div>
  );
}

function Container123() {
  return (
    <div className="content-stretch flex gap-[12px] h-[73px] items-start pt-[17px] relative shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-solid border-t inset-0 pointer-events-none" />
      <Container124 />
      <Container125 />
    </div>
  );
}

function Container122() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[24px] h-[142.5px] items-start left-[26px] top-[26px] w-[489.5px]" data-name="Container">
      <Paragraph12 />
      <Container123 />
    </div>
  );
}

function Container120() {
  return (
    <div className="col-1 justify-self-stretch relative rounded-[14px] row-1 self-stretch shrink-0" data-name="Container" style={{ backgroundImage: "linear-gradient(160.242deg, rgb(249, 250, 251) 0%, rgb(255, 255, 255) 100%)" }}>
      <div aria-hidden="true" className="absolute border-2 border-[#e5e7eb] border-solid inset-0 pointer-events-none rounded-[14px]" />
      <Container121 />
      <Container122 />
    </div>
  );
}

function Icon13() {
  return (
    <div className="h-[48px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[12.5%_12.5%_12.5%_58.33%]" data-name="Vector">
        <div className="absolute inset-[-5.56%_-14.29%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 40">
            <path d={svgPaths.p98a0a70} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[12.5%_58.33%_12.5%_12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.56%_-14.29%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 40">
            <path d={svgPaths.p2ce0db40} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Container130() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[467.5px] opacity-10 size-[48px] top-[26px]" data-name="Container">
      <Icon13 />
    </div>
  );
}

function Paragraph13() {
  return (
    <div className="h-[45.5px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[22.75px] left-0 not-italic text-[#364153] text-[14px] top-0 tracking-[-0.1504px] w-[473px] whitespace-pre-wrap">{`"Safety is non-negotiable in my practice. The 13-point monitoring system has eliminated my concerns about adverse events entirely."`}</p>
    </div>
  );
}

function Icon14() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g clipPath="url(#clip0_1_895)" id="Icon">
          <path d={svgPaths.p37143280} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p1d7f0000} id="Vector_2" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p2b722f80} id="Vector_3" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33333 5H11.6667" id="Vector_4" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33333 8.33333H11.6667" id="Vector_5" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33333 11.6667H11.6667" id="Vector_6" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33333 15H11.6667" id="Vector_7" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
        <defs>
          <clipPath id="clip0_1_895">
            <rect fill="white" height="20" width="20" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container133() {
  return (
    <div className="bg-[#dbeafe] relative rounded-[33554400px] shrink-0 size-[40px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon14 />
      </div>
    </div>
  );
}

function Container135() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[20px] left-0 not-italic text-[#101828] text-[14px] top-0 tracking-[-0.1504px]">Dr. Mart Maiprasert</p>
    </div>
  );
}

function Container136() {
  return (
    <div className="content-stretch flex h-[16px] items-start relative shrink-0 w-full" data-name="Container">
      <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[16px] min-h-px min-w-px not-italic relative text-[#4a5565] text-[12px] whitespace-pre-wrap">Dean at College of Integrative Medicine</p>
    </div>
  );
}

function Container137() {
  return (
    <div className="content-stretch flex h-[16px] items-start relative shrink-0 w-full" data-name="Container">
      <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[16px] min-h-px min-w-px not-italic relative text-[#155dfc] text-[12px] whitespace-pre-wrap">Dhurakij Pundit University</p>
    </div>
  );
}

function Container134() {
  return (
    <div className="flex-[1_0_0] h-[56px] min-h-px min-w-px relative" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Container135 />
        <Container136 />
        <Container137 />
      </div>
    </div>
  );
}

function Container132() {
  return (
    <div className="content-stretch flex gap-[12px] h-[73px] items-start pt-[17px] relative shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-solid border-t inset-0 pointer-events-none" />
      <Container133 />
      <Container134 />
    </div>
  );
}

function Container131() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[24px] h-[142.5px] items-start left-[26px] top-[26px] w-[489.5px]" data-name="Container">
      <Paragraph13 />
      <Container132 />
    </div>
  );
}

function Container129() {
  return (
    <div className="col-2 justify-self-stretch relative rounded-[14px] row-1 self-stretch shrink-0" data-name="Container" style={{ backgroundImage: "linear-gradient(160.242deg, rgb(249, 250, 251) 0%, rgb(255, 255, 255) 100%)" }}>
      <div aria-hidden="true" className="absolute border-2 border-[#e5e7eb] border-solid inset-0 pointer-events-none rounded-[14px]" />
      <Container130 />
      <Container131 />
    </div>
  );
}

function Icon15() {
  return (
    <div className="h-[48px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[12.5%_12.5%_12.5%_58.33%]" data-name="Vector">
        <div className="absolute inset-[-5.56%_-14.29%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 40">
            <path d={svgPaths.p98a0a70} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[12.5%_58.33%_12.5%_12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.56%_-14.29%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 40">
            <path d={svgPaths.p2ce0db40} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Container139() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[467.5px] opacity-10 size-[48px] top-[26px]" data-name="Container">
      <Icon15 />
    </div>
  );
}

function Paragraph14() {
  return (
    <div className="h-[45.5px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[22.75px] left-0 not-italic text-[#364153] text-[14px] top-0 tracking-[-0.1504px] w-[467px] whitespace-pre-wrap">{`"My patients report minimal discomfort and faster recovery compared to traditional needling. The results speak for themselves."`}</p>
    </div>
  );
}

function Icon16() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g clipPath="url(#clip0_1_895)" id="Icon">
          <path d={svgPaths.p37143280} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p1d7f0000} id="Vector_2" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p2b722f80} id="Vector_3" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33333 5H11.6667" id="Vector_4" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33333 8.33333H11.6667" id="Vector_5" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33333 11.6667H11.6667" id="Vector_6" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33333 15H11.6667" id="Vector_7" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
        <defs>
          <clipPath id="clip0_1_895">
            <rect fill="white" height="20" width="20" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container142() {
  return (
    <div className="bg-[#dbeafe] relative rounded-[33554400px] shrink-0 size-[40px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon16 />
      </div>
    </div>
  );
}

function Container144() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[20px] left-0 not-italic text-[#101828] text-[14px] top-0 tracking-[-0.1504px]">Dr. Natcha Na Nongkhai</p>
    </div>
  );
}

function Container145() {
  return (
    <div className="content-stretch flex h-[16px] items-start relative shrink-0 w-full" data-name="Container">
      <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[16px] min-h-px min-w-px not-italic relative text-[#4a5565] text-[12px] whitespace-pre-wrap">Dermatology Doctor</p>
    </div>
  );
}

function Container146() {
  return (
    <div className="content-stretch flex h-[16px] items-start relative shrink-0 w-full" data-name="Container">
      <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[16px] min-h-px min-w-px not-italic relative text-[#155dfc] text-[12px] whitespace-pre-wrap">APEX Medical Beauty, Bangkok</p>
    </div>
  );
}

function Container143() {
  return (
    <div className="flex-[1_0_0] h-[56px] min-h-px min-w-px relative" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Container144 />
        <Container145 />
        <Container146 />
      </div>
    </div>
  );
}

function Container141() {
  return (
    <div className="content-stretch flex gap-[12px] h-[73px] items-start pt-[17px] relative shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-solid border-t inset-0 pointer-events-none" />
      <Container142 />
      <Container143 />
    </div>
  );
}

function Container140() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[24px] h-[142.5px] items-start left-[26px] top-[26px] w-[489.5px]" data-name="Container">
      <Paragraph14 />
      <Container141 />
    </div>
  );
}

function Container138() {
  return (
    <div className="col-1 justify-self-stretch relative rounded-[14px] row-2 self-stretch shrink-0" data-name="Container" style={{ backgroundImage: "linear-gradient(160.242deg, rgb(249, 250, 251) 0%, rgb(255, 255, 255) 100%)" }}>
      <div aria-hidden="true" className="absolute border-2 border-[#e5e7eb] border-solid inset-0 pointer-events-none rounded-[14px]" />
      <Container139 />
      <Container140 />
    </div>
  );
}

function Icon17() {
  return (
    <div className="h-[48px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[12.5%_12.5%_12.5%_58.33%]" data-name="Vector">
        <div className="absolute inset-[-5.56%_-14.29%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 40">
            <path d={svgPaths.p98a0a70} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[12.5%_58.33%_12.5%_12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.56%_-14.29%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 40">
            <path d={svgPaths.p2ce0db40} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Container148() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[467.5px] opacity-10 size-[48px] top-[26px]" data-name="Container">
      <Icon17 />
    </div>
  );
}

function Paragraph15() {
  return (
    <div className="h-[45.5px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[22.75px] left-0 not-italic text-[#364153] text-[14px] top-0 tracking-[-0.1504px] w-[469px] whitespace-pre-wrap">{`"re:H has transformed how we approach hair scalp revision. The precision and safety profile allow us to treat cases we couldn't before."`}</p>
    </div>
  );
}

function Icon18() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g clipPath="url(#clip0_1_895)" id="Icon">
          <path d={svgPaths.p37143280} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p1d7f0000} id="Vector_2" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p2b722f80} id="Vector_3" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33333 5H11.6667" id="Vector_4" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33333 8.33333H11.6667" id="Vector_5" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33333 11.6667H11.6667" id="Vector_6" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33333 15H11.6667" id="Vector_7" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
        <defs>
          <clipPath id="clip0_1_895">
            <rect fill="white" height="20" width="20" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container151() {
  return (
    <div className="bg-[#dbeafe] relative rounded-[33554400px] shrink-0 size-[40px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon18 />
      </div>
    </div>
  );
}

function Container153() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[20px] left-0 not-italic text-[#101828] text-[14px] top-0 tracking-[-0.1504px]">Dr. Chinmanat Lekhavat</p>
    </div>
  );
}

function Container154() {
  return (
    <div className="content-stretch flex h-[16px] items-start relative shrink-0 w-full" data-name="Container">
      <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[16px] min-h-px min-w-px not-italic relative text-[#4a5565] text-[12px] whitespace-pre-wrap">Hair Surgeon</p>
    </div>
  );
}

function Container155() {
  return (
    <div className="content-stretch flex h-[16px] items-start relative shrink-0 w-full" data-name="Container">
      <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[16px] min-h-px min-w-px not-italic relative text-[#155dfc] text-[12px] whitespace-pre-wrap">Institute of Dermatology, Thailand</p>
    </div>
  );
}

function Container152() {
  return (
    <div className="flex-[1_0_0] h-[56px] min-h-px min-w-px relative" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Container153 />
        <Container154 />
        <Container155 />
      </div>
    </div>
  );
}

function Container150() {
  return (
    <div className="content-stretch flex gap-[12px] h-[73px] items-start pt-[17px] relative shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-solid border-t inset-0 pointer-events-none" />
      <Container151 />
      <Container152 />
    </div>
  );
}

function Container149() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[24px] h-[142.5px] items-start left-[26px] top-[26px] w-[489.5px]" data-name="Container">
      <Paragraph15 />
      <Container150 />
    </div>
  );
}

function Container147() {
  return (
    <div className="col-2 justify-self-stretch relative rounded-[14px] row-2 self-stretch shrink-0" data-name="Container" style={{ backgroundImage: "linear-gradient(160.242deg, rgb(249, 250, 251) 0%, rgb(255, 255, 255) 100%)" }}>
      <div aria-hidden="true" className="absolute border-2 border-[#e5e7eb] border-solid inset-0 pointer-events-none rounded-[14px]" />
      <Container148 />
      <Container149 />
    </div>
  );
}

function Container119() {
  return (
    <div className="gap-x-[24px] gap-y-[24px] grid grid-cols-[repeat(2,minmax(0,1fr))] grid-rows-[repeat(2,minmax(0,1fr))] h-[413px] relative shrink-0 w-full" data-name="Container">
      <Container120 />
      <Container129 />
      <Container138 />
      <Container147 />
    </div>
  );
}

function Paragraph16() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="-translate-x-1/2 absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[554.09px] not-italic text-[#4a5565] text-[14px] text-center top-0 tracking-[-0.1504px]">Explore detailed clinical case studies showcasing real-world results across multiple indications</p>
    </div>
  );
}

function Container116() {
  return (
    <div className="h-[818px] relative shrink-0 w-full" data-name="Container">
      <div className="content-stretch flex flex-col gap-[40px] items-start px-[32px] relative size-full">
        <Container117 />
        <Container119 />
        <Paragraph16 />
      </div>
    </div>
  );
}

function ClinicalEvidence() {
  return (
    <div className="bg-white content-stretch flex flex-col h-[709px] items-start overflow-clip relative shrink-0 w-full" data-name="ClinicalEvidence">
      <Container116 />
    </div>
  );
}

function Icon19() {
  return (
    <div className="absolute left-[16px] size-[16px] top-[10px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p14548f00} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p17781bc0} id="Vector_2" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Text13() {
  return (
    <div className="absolute h-[20px] left-[40px] top-[8px] w-[149.953px]" data-name="Text">
      <p className="-translate-x-1/2 absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[20px] left-[75.5px] not-italic text-[#1447e6] text-[14px] text-center top-0 tracking-[-0.1504px]">6+ Certified Locations</p>
    </div>
  );
}

function Container158() {
  return (
    <div className="absolute bg-[#eff6ff] border border-[#bedbff] border-solid h-[38px] left-[449.52px] rounded-[33554400px] top-0 w-[207.953px]" data-name="Container">
      <Icon19 />
      <Text13 />
    </div>
  );
}

function Heading14() {
  return (
    <div className="absolute h-[48px] left-0 top-[54px] w-[1107px]" data-name="Heading 2">
      <p className="-translate-x-1/2 absolute font-['Inter:Bold',sans-serif] font-bold leading-[48px] left-[553.67px] not-italic text-[#101828] text-[48px] text-center top-px tracking-[-0.1284px]">Find re:H Certified Clinic</p>
    </div>
  );
}

function Paragraph17() {
  return (
    <div className="absolute h-[28px] left-[217.5px] top-[114px] w-[672px]" data-name="Paragraph">
      <p className="-translate-x-1/2 absolute font-['Inter:Regular',sans-serif] font-normal leading-[28px] left-[336.94px] not-italic text-[#4a5565] text-[18px] text-center top-0 tracking-[-0.4395px]">SSCM technology available exclusively at certified medical facilities</p>
    </div>
  );
}

function Container157() {
  return (
    <div className="h-[142px] relative shrink-0 w-full" data-name="Container">
      <Container158 />
      <Heading14 />
      <Paragraph17 />
    </div>
  );
}

function Button3() {
  return (
    <div className="absolute bg-[#155dfc] h-[38px] left-[298.14px] rounded-[33554400px] shadow-[0px_10px_15px_0px_rgba(0,0,0,0.1),0px_4px_6px_0px_rgba(0,0,0,0.1)] top-0 w-[108.359px]" data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[54px] not-italic text-[14px] text-center text-white top-[9px] tracking-[0.1296px]">All Regions</p>
    </div>
  );
}

function Button4() {
  return (
    <div className="absolute bg-white border border-[#e5e7eb] border-solid h-[38px] left-[414.5px] rounded-[33554400px] top-0 w-[93.047px]" data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[46.5px] not-italic text-[#364153] text-[14px] text-center top-[8px] tracking-[0.1296px]">Bangkok</p>
    </div>
  );
}

function Button5() {
  return (
    <div className="absolute bg-white border border-[#e5e7eb] border-solid h-[38px] left-[515.55px] rounded-[33554400px] top-0 w-[110.266px]" data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[54.5px] not-italic text-[#364153] text-[14px] text-center top-[8px] tracking-[0.1296px]">Chiang Mai</p>
    </div>
  );
}

function Button6() {
  return (
    <div className="absolute bg-white border border-[#e5e7eb] border-solid h-[38px] left-[633.81px] rounded-[33554400px] top-0 w-[81.625px]" data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[40px] not-italic text-[#364153] text-[14px] text-center top-[8px] tracking-[0.1296px]">Phuket</p>
    </div>
  );
}

function Button7() {
  return (
    <div className="absolute bg-white border border-[#e5e7eb] border-solid h-[38px] left-[723.44px] rounded-[33554400px] top-0 w-[85.422px]" data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[42px] not-italic text-[#364153] text-[14px] text-center top-[8px] tracking-[0.1296px]">Pattaya</p>
    </div>
  );
}

function Container160() {
  return (
    <div className="absolute h-[38px] left-0 top-[62px] w-[1107px]" data-name="Container">
      <Button3 />
      <Button4 />
      <Button5 />
      <Button6 />
      <Button7 />
    </div>
  );
}

function TextInput() {
  return (
    <div className="absolute h-[46px] left-0 rounded-[10px] top-0 w-[576px]" data-name="Text Input">
      <div className="content-stretch flex items-center overflow-clip pl-[48px] pr-[16px] py-[12px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[normal] not-italic relative shrink-0 text-[14px] text-[rgba(10,10,10,0.5)] tracking-[-0.1504px]">Search by clinic or location...</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[#d1d5dc] border-solid inset-0 pointer-events-none rounded-[10px]" />
    </div>
  );
}

function Icon20() {
  return (
    <div className="absolute left-[16px] size-[18px] top-[14px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="Icon">
          <path d={svgPaths.p126da180} id="Vector" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p89d1980} id="Vector_2" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Container161() {
  return (
    <div className="absolute h-[46px] left-[265.5px] top-0 w-[576px]" data-name="Container">
      <TextInput />
      <Icon20 />
    </div>
  );
}

function Container159() {
  return (
    <div className="h-[100px] relative shrink-0 w-full" data-name="Container">
      <Container160 />
      <Container161 />
    </div>
  );
}

function Icon21() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g clipPath="url(#clip0_1_882)" id="Icon">
          <path d={svgPaths.p3b43bb80} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p1d7f0000} id="Vector_2" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p2b722f80} id="Vector_3" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33333 5H11.6667" id="Vector_4" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33334 8.33301H11.6667" id="Vector_5" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33334 11.667H11.6667" id="Vector_6" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33333 15H11.6667" id="Vector_7" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
        <defs>
          <clipPath id="clip0_1_882">
            <rect fill="white" height="20" width="20" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container165() {
  return (
    <div className="bg-[#dbeafe] relative rounded-[10px] shrink-0 size-[40px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon21 />
      </div>
    </div>
  );
}

function Container166() {
  return (
    <div className="bg-[#dbeafe] h-[24px] relative rounded-[33554400px] shrink-0 w-[79.875px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start px-[8px] py-[4px] relative size-full">
        <p className="font-['Inter:Bold',sans-serif] font-bold leading-[16px] not-italic relative shrink-0 text-[#1447e6] text-[12px]">CERTIFIED</p>
      </div>
    </div>
  );
}

function Container164() {
  return (
    <div className="absolute content-stretch flex h-[40px] items-start justify-between left-[20px] top-[20px] w-[314.328px]" data-name="Container">
      <Container165 />
      <Container166 />
    </div>
  );
}

function Heading15() {
  return (
    <div className="absolute h-[20px] left-[20px] top-[72px] w-[314.328px]" data-name="Heading 3">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[20px] left-0 not-italic text-[#101828] text-[14px] top-0 tracking-[-0.2904px]">APEX Surgery Hospital - Ploenchit</p>
    </div>
  );
}

function Icon22() {
  return (
    <div className="absolute left-0 size-[14px] top-[2px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Icon">
          <path d={svgPaths.pba7ec40} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d={svgPaths.pbd96b00} id="Vector_2" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
      </svg>
    </div>
  );
}

function Text14() {
  return (
    <div className="absolute content-stretch flex h-[16px] items-start left-[22px] top-0 w-[108.297px]" data-name="Text">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#4a5565] text-[12px]">82 Sukhumvit Rd, Bangkok</p>
    </div>
  );
}

function Container168() {
  return (
    <div className="h-[16px] relative shrink-0 w-full" data-name="Container">
      <Icon22 />
      <Text14 />
    </div>
  );
}

function Icon23() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g clipPath="url(#clip0_1_984)" id="Icon">
          <path d={svgPaths.p34cde680} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d="M7 3.5V7L9.33333 8.16667" id="Vector_2" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
        <defs>
          <clipPath id="clip0_1_984">
            <rect fill="white" height="14" width="14" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text15() {
  return (
    <div className="h-[16px] relative shrink-0 w-[119.703px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#4a5565] text-[12px]">Daily: 8:30-20:30</p>
      </div>
    </div>
  );
}

function Container169() {
  return (
    <div className="content-stretch flex gap-[8px] h-[16px] items-center relative shrink-0 w-full" data-name="Container">
      <Icon23 />
      <Text15 />
    </div>
  );
}

function Container167() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[40px] items-start left-[20px] top-[100px] w-[314.328px]" data-name="Container">
      <Container168 />
      <Container169 />
    </div>
  );
}

function Text16() {
  return (
    <div className="absolute bg-[#f3f4f6] content-stretch flex h-[24px] items-start left-0 px-[8px] py-[4px] rounded-[33554400px] top-0 w-[129.656px]" data-name="Text">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#364153] text-[12px]">Surgical Procedures</p>
    </div>
  );
}

function Text17() {
  return (
    <div className="absolute bg-[#f3f4f6] content-stretch flex h-[24px] items-start left-[133.66px] px-[8px] py-[4px] rounded-[33554400px] top-0 w-[134.734px]" data-name="Text">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#364153] text-[12px]">Advanced Aesthetics</p>
    </div>
  );
}

function Container170() {
  return (
    <div className="absolute h-[24px] left-[20px] top-[156px] w-[314.328px]" data-name="Container">
      <Text16 />
      <Text17 />
    </div>
  );
}

function Icon24() {
  return (
    <div className="absolute left-[110.11px] size-[16px] top-[10px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p9d0d100} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button8() {
  return (
    <div className="absolute bg-[#155dfc] h-[36px] left-[20px] rounded-[10px] top-[196px] w-[314.328px]" data-name="Button">
      <Icon24 />
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[169.11px] not-italic text-[14px] text-center text-white top-[8px] tracking-[0.1296px]">Directions</p>
    </div>
  );
}

function Container163() {
  return (
    <div className="absolute bg-white border-2 border-[#e5e7eb] border-solid h-[256px] left-0 rounded-[14px] top-0 w-[358.328px]" data-name="Container">
      <Container164 />
      <Heading15 />
      <Container167 />
      <Container170 />
      <Button8 />
    </div>
  );
}

function Icon25() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g clipPath="url(#clip0_1_873)" id="Icon">
          <path d={svgPaths.p3b43bb80} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p1d7f0000} id="Vector_2" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p2b722f80} id="Vector_3" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33333 5H11.6667" id="Vector_4" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33334 8.33301H11.6667" id="Vector_5" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33334 11.667H11.6667" id="Vector_6" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33333 15H11.6667" id="Vector_7" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
        <defs>
          <clipPath id="clip0_1_873">
            <rect fill="white" height="20" width="20" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container173() {
  return (
    <div className="bg-[#dbeafe] relative rounded-[10px] shrink-0 size-[40px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon25 />
      </div>
    </div>
  );
}

function Container174() {
  return (
    <div className="bg-[#dbeafe] h-[24px] relative rounded-[33554400px] shrink-0 w-[79.875px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start px-[8px] py-[4px] relative size-full">
        <p className="font-['Inter:Bold',sans-serif] font-bold leading-[16px] not-italic relative shrink-0 text-[#1447e6] text-[12px]">CERTIFIED</p>
      </div>
    </div>
  );
}

function Container172() {
  return (
    <div className="absolute content-stretch flex h-[40px] items-start justify-between left-[20px] top-[20px] w-[314.328px]" data-name="Container">
      <Container173 />
      <Container174 />
    </div>
  );
}

function Heading16() {
  return (
    <div className="absolute h-[20px] left-[20px] top-[72px] w-[314.328px]" data-name="Heading 3">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[20px] left-0 not-italic text-[#101828] text-[14px] top-0 tracking-[-0.2904px]">APEX Beauty - Thonglor</p>
    </div>
  );
}

function Icon26() {
  return (
    <div className="absolute left-0 size-[14px] top-[2px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Icon">
          <path d={svgPaths.p3833ce80} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d={svgPaths.pbd96b00} id="Vector_2" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
      </svg>
    </div>
  );
}

function Text18() {
  return (
    <div className="absolute content-stretch flex h-[16px] items-start left-[22px] top-0 w-[171.797px]" data-name="Text">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#4a5565] text-[12px]">Thonglor Soi 8, Sukhumvit, Bangkok</p>
    </div>
  );
}

function Container176() {
  return (
    <div className="h-[16px] relative shrink-0 w-full" data-name="Container">
      <Icon26 />
      <Text18 />
    </div>
  );
}

function Icon27() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g clipPath="url(#clip0_1_865)" id="Icon">
          <path d={svgPaths.p1c90cd00} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d="M7 3.5V7L9.33333 8.16667" id="Vector_2" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
        <defs>
          <clipPath id="clip0_1_865">
            <rect fill="white" height="14" width="14" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text19() {
  return (
    <div className="h-[16px] relative shrink-0 w-[105.75px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#4a5565] text-[12px]">Daily: 8:30-20:00</p>
      </div>
    </div>
  );
}

function Container177() {
  return (
    <div className="content-stretch flex gap-[8px] h-[16px] items-center relative shrink-0 w-full" data-name="Container">
      <Icon27 />
      <Text19 />
    </div>
  );
}

function Container175() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[40px] items-start left-[20px] top-[100px] w-[314.328px]" data-name="Container">
      <Container176 />
      <Container177 />
    </div>
  );
}

function Text20() {
  return (
    <div className="absolute bg-[#f3f4f6] content-stretch flex h-[24px] items-start left-0 px-[8px] py-[4px] rounded-[33554400px] top-0 w-[116.156px]" data-name="Text">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#364153] text-[12px]">Skin Rejuvenation</p>
    </div>
  );
}

function Text21() {
  return (
    <div className="absolute bg-[#f3f4f6] content-stretch flex h-[24px] items-start left-[120.16px] px-[8px] py-[4px] rounded-[33554400px] top-0 w-[117.531px]" data-name="Text">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#364153] text-[12px]">SSCM Treatments</p>
    </div>
  );
}

function Container178() {
  return (
    <div className="absolute h-[24px] left-[20px] top-[156px] w-[314.328px]" data-name="Container">
      <Text20 />
      <Text21 />
    </div>
  );
}

function Icon28() {
  return (
    <div className="absolute left-[110.11px] size-[16px] top-[10px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p9d0d100} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button9() {
  return (
    <div className="absolute bg-[#155dfc] h-[36px] left-[20px] rounded-[10px] top-[196px] w-[314.328px]" data-name="Button">
      <Icon28 />
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[169.11px] not-italic text-[14px] text-center text-white top-[8px] tracking-[0.1296px]">Directions</p>
    </div>
  );
}

function Container171() {
  return (
    <div className="absolute bg-white border-2 border-[#e5e7eb] border-solid h-[256px] left-[374.33px] rounded-[14px] top-0 w-[358.328px]" data-name="Container">
      <Container172 />
      <Heading16 />
      <Container175 />
      <Container178 />
      <Button9 />
    </div>
  );
}

function Icon29() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g clipPath="url(#clip0_1_914)" id="Icon">
          <path d={svgPaths.p3b43bb80} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p1d7f0000} id="Vector_2" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p2b722f80} id="Vector_3" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33333 5H11.6667" id="Vector_4" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33331 8.33301H11.6666" id="Vector_5" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33331 11.667H11.6666" id="Vector_6" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33333 15H11.6667" id="Vector_7" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
        <defs>
          <clipPath id="clip0_1_914">
            <rect fill="white" height="20" width="20" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container181() {
  return (
    <div className="bg-[#dbeafe] relative rounded-[10px] shrink-0 size-[40px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon29 />
      </div>
    </div>
  );
}

function Container182() {
  return (
    <div className="bg-[#dbeafe] h-[24px] relative rounded-[33554400px] shrink-0 w-[79.875px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start px-[8px] py-[4px] relative size-full">
        <p className="font-['Inter:Bold',sans-serif] font-bold leading-[16px] not-italic relative shrink-0 text-[#1447e6] text-[12px]">CERTIFIED</p>
      </div>
    </div>
  );
}

function Container180() {
  return (
    <div className="absolute content-stretch flex h-[40px] items-start justify-between left-[20px] top-[20px] w-[314.344px]" data-name="Container">
      <Container181 />
      <Container182 />
    </div>
  );
}

function Heading17() {
  return (
    <div className="absolute h-[20px] left-[20px] top-[72px] w-[314.344px]" data-name="Heading 3">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[20px] left-0 not-italic text-[#101828] text-[14px] top-0 tracking-[-0.2904px]">APEX Beauty - Siam Paragon</p>
    </div>
  );
}

function Icon30() {
  return (
    <div className="absolute left-0 size-[14px] top-[2px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Icon">
          <path d={svgPaths.p4623500} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d={svgPaths.pbd96b00} id="Vector_2" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
      </svg>
    </div>
  );
}

function Text22() {
  return (
    <div className="absolute content-stretch flex h-[16px] items-start left-[22px] top-0 w-[133.25px]" data-name="Text">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#4a5565] text-[12px]">Siam Paragon, Bangkok</p>
    </div>
  );
}

function Container184() {
  return (
    <div className="h-[16px] relative shrink-0 w-full" data-name="Container">
      <Icon30 />
      <Text22 />
    </div>
  );
}

function Icon31() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g clipPath="url(#clip0_1_853)" id="Icon">
          <path d={svgPaths.p11235db0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d="M7 3.5V7L9.33333 8.16667" id="Vector_2" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
        <defs>
          <clipPath id="clip0_1_853">
            <rect fill="white" height="14" width="14" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text23() {
  return (
    <div className="h-[16px] relative shrink-0 w-[105.422px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#4a5565] text-[12px]">Daily: 10:00-21:00</p>
      </div>
    </div>
  );
}

function Container185() {
  return (
    <div className="content-stretch flex gap-[8px] h-[16px] items-center relative shrink-0 w-full" data-name="Container">
      <Icon31 />
      <Text23 />
    </div>
  );
}

function Container183() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[40px] items-start left-[20px] top-[100px] w-[314.344px]" data-name="Container">
      <Container184 />
      <Container185 />
    </div>
  );
}

function Text24() {
  return (
    <div className="absolute bg-[#f3f4f6] content-stretch flex h-[24px] items-start left-0 px-[8px] py-[4px] rounded-[33554400px] top-0 w-[115.578px]" data-name="Text">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#364153] text-[12px]">Facial Treatments</p>
    </div>
  );
}

function Text25() {
  return (
    <div className="absolute bg-[#f3f4f6] content-stretch flex h-[24px] items-start left-[119.58px] px-[8px] py-[4px] rounded-[33554400px] top-0 w-[90.609px]" data-name="Text">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#364153] text-[12px]">Pigmentation</p>
    </div>
  );
}

function Container186() {
  return (
    <div className="absolute h-[24px] left-[20px] top-[156px] w-[314.344px]" data-name="Container">
      <Text24 />
      <Text25 />
    </div>
  );
}

function Icon32() {
  return (
    <div className="absolute left-[110.13px] size-[16px] top-[10px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p9d0d100} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button10() {
  return (
    <div className="absolute bg-[#155dfc] h-[36px] left-[20px] rounded-[10px] top-[196px] w-[314.344px]" data-name="Button">
      <Icon32 />
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[169.13px] not-italic text-[14px] text-center text-white top-[8px] tracking-[0.1296px]">Directions</p>
    </div>
  );
}

function Container179() {
  return (
    <div className="absolute bg-white border-2 border-[#e5e7eb] border-solid h-[256px] left-[748.66px] rounded-[14px] top-0 w-[358.344px]" data-name="Container">
      <Container180 />
      <Heading17 />
      <Container183 />
      <Container186 />
      <Button10 />
    </div>
  );
}

function Icon33() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g clipPath="url(#clip0_1_882)" id="Icon">
          <path d={svgPaths.p3b43bb80} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p1d7f0000} id="Vector_2" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p2b722f80} id="Vector_3" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33333 5H11.6667" id="Vector_4" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33334 8.33301H11.6667" id="Vector_5" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33334 11.667H11.6667" id="Vector_6" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33333 15H11.6667" id="Vector_7" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
        <defs>
          <clipPath id="clip0_1_882">
            <rect fill="white" height="20" width="20" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container189() {
  return (
    <div className="bg-[#dbeafe] relative rounded-[10px] shrink-0 size-[40px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon33 />
      </div>
    </div>
  );
}

function Container190() {
  return (
    <div className="bg-[#dbeafe] h-[24px] relative rounded-[33554400px] shrink-0 w-[79.875px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start px-[8px] py-[4px] relative size-full">
        <p className="font-['Inter:Bold',sans-serif] font-bold leading-[16px] not-italic relative shrink-0 text-[#1447e6] text-[12px]">CERTIFIED</p>
      </div>
    </div>
  );
}

function Container188() {
  return (
    <div className="absolute content-stretch flex h-[40px] items-start justify-between left-[20px] top-[20px] w-[314.328px]" data-name="Container">
      <Container189 />
      <Container190 />
    </div>
  );
}

function Heading18() {
  return (
    <div className="absolute h-[20px] left-[20px] top-[72px] w-[314.328px]" data-name="Heading 3">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[20px] left-0 not-italic text-[#101828] text-[14px] top-0 tracking-[-0.2904px]">APEX Beauty - EmQuartier</p>
    </div>
  );
}

function Icon34() {
  return (
    <div className="absolute left-0 size-[14px] top-[2px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Icon">
          <path d={svgPaths.pba7ec40} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d={svgPaths.pbd96b00} id="Vector_2" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
      </svg>
    </div>
  );
}

function Text26() {
  return (
    <div className="absolute content-stretch flex h-[16px] items-start left-[22px] top-0 w-[184.938px]" data-name="Text">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#4a5565] text-[12px]">EmQuartier, Sukhumvit, Bangkok</p>
    </div>
  );
}

function Container192() {
  return (
    <div className="h-[16px] relative shrink-0 w-full" data-name="Container">
      <Icon34 />
      <Text26 />
    </div>
  );
}

function Icon35() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g clipPath="url(#clip0_1_984)" id="Icon">
          <path d={svgPaths.p34cde680} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d="M7 3.5V7L9.33333 8.16667" id="Vector_2" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
        <defs>
          <clipPath id="clip0_1_984">
            <rect fill="white" height="14" width="14" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text27() {
  return (
    <div className="h-[16px] relative shrink-0 w-[105.422px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#4a5565] text-[12px]">Daily: 10:00-21:00</p>
      </div>
    </div>
  );
}

function Container193() {
  return (
    <div className="content-stretch flex gap-[8px] h-[16px] items-center relative shrink-0 w-full" data-name="Container">
      <Icon35 />
      <Text27 />
    </div>
  );
}

function Container191() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[40px] items-start left-[20px] top-[100px] w-[314.328px]" data-name="Container">
      <Container192 />
      <Container193 />
    </div>
  );
}

function Text28() {
  return (
    <div className="absolute bg-[#f3f4f6] content-stretch flex h-[24px] items-start left-0 px-[8px] py-[4px] rounded-[33554400px] top-0 w-[122.844px]" data-name="Text">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#364153] text-[12px]">Medical Aesthetics</p>
    </div>
  );
}

function Text29() {
  return (
    <div className="absolute bg-[#f3f4f6] content-stretch flex h-[24px] items-start left-[126.84px] px-[8px] py-[4px] rounded-[33554400px] top-0 w-[96.063px]" data-name="Text">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#364153] text-[12px]">Microneedling</p>
    </div>
  );
}

function Container194() {
  return (
    <div className="absolute h-[24px] left-[20px] top-[156px] w-[314.328px]" data-name="Container">
      <Text28 />
      <Text29 />
    </div>
  );
}

function Icon36() {
  return (
    <div className="absolute left-[110.11px] size-[16px] top-[10px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p9d0d100} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button11() {
  return (
    <div className="absolute bg-[#155dfc] h-[36px] left-[20px] rounded-[10px] top-[196px] w-[314.328px]" data-name="Button">
      <Icon36 />
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[169.11px] not-italic text-[14px] text-center text-white top-[8px] tracking-[0.1296px]">Directions</p>
    </div>
  );
}

function Container187() {
  return (
    <div className="absolute bg-white border-2 border-[#e5e7eb] border-solid h-[256px] left-0 rounded-[14px] top-[272px] w-[358.328px]" data-name="Container">
      <Container188 />
      <Heading18 />
      <Container191 />
      <Container194 />
      <Button11 />
    </div>
  );
}

function Icon37() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g clipPath="url(#clip0_1_873)" id="Icon">
          <path d={svgPaths.p3b43bb80} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p1d7f0000} id="Vector_2" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p2b722f80} id="Vector_3" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33333 5H11.6667" id="Vector_4" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33334 8.33301H11.6667" id="Vector_5" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33334 11.667H11.6667" id="Vector_6" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33333 15H11.6667" id="Vector_7" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
        <defs>
          <clipPath id="clip0_1_873">
            <rect fill="white" height="20" width="20" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container197() {
  return (
    <div className="bg-[#dbeafe] relative rounded-[10px] shrink-0 size-[40px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon37 />
      </div>
    </div>
  );
}

function Container198() {
  return (
    <div className="bg-[#dbeafe] h-[24px] relative rounded-[33554400px] shrink-0 w-[79.875px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start px-[8px] py-[4px] relative size-full">
        <p className="font-['Inter:Bold',sans-serif] font-bold leading-[16px] not-italic relative shrink-0 text-[#1447e6] text-[12px]">CERTIFIED</p>
      </div>
    </div>
  );
}

function Container196() {
  return (
    <div className="absolute content-stretch flex h-[40px] items-start justify-between left-[20px] top-[20px] w-[314.328px]" data-name="Container">
      <Container197 />
      <Container198 />
    </div>
  );
}

function Heading19() {
  return (
    <div className="absolute h-[20px] left-[20px] top-[72px] w-[314.328px]" data-name="Heading 3">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[20px] left-0 not-italic text-[#101828] text-[14px] top-0 tracking-[-0.2904px]">APEX Beauty - Dusit Central</p>
    </div>
  );
}

function Icon38() {
  return (
    <div className="absolute left-0 size-[14px] top-[2px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Icon">
          <path d={svgPaths.p3833ce80} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d={svgPaths.pbd96b00} id="Vector_2" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
      </svg>
    </div>
  );
}

function Text30() {
  return (
    <div className="absolute content-stretch flex h-[16px] items-start left-[22px] top-0 w-[157.797px]" data-name="Text">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#4a5565] text-[12px]">Dusit Central Park, Bangkok</p>
    </div>
  );
}

function Container200() {
  return (
    <div className="h-[16px] relative shrink-0 w-full" data-name="Container">
      <Icon38 />
      <Text30 />
    </div>
  );
}

function Icon39() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g clipPath="url(#clip0_1_865)" id="Icon">
          <path d={svgPaths.p1c90cd00} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d="M7 3.5V7L9.33333 8.16667" id="Vector_2" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
        <defs>
          <clipPath id="clip0_1_865">
            <rect fill="white" height="14" width="14" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text31() {
  return (
    <div className="h-[16px] relative shrink-0 w-[105.422px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#4a5565] text-[12px]">Daily: 10:30-22:00</p>
      </div>
    </div>
  );
}

function Container201() {
  return (
    <div className="content-stretch flex gap-[8px] h-[16px] items-center relative shrink-0 w-full" data-name="Container">
      <Icon39 />
      <Text31 />
    </div>
  );
}

function Container199() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[40px] items-start left-[20px] top-[100px] w-[314.328px]" data-name="Container">
      <Container200 />
      <Container201 />
    </div>
  );
}

function Text32() {
  return (
    <div className="absolute bg-[#f3f4f6] content-stretch flex h-[24px] items-start left-0 px-[8px] py-[4px] rounded-[33554400px] top-0 w-[124.031px]" data-name="Text">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#364153] text-[12px]">Advanced Skincare</p>
    </div>
  );
}

function Text33() {
  return (
    <div className="absolute bg-[#f3f4f6] content-stretch flex h-[24px] items-start left-[128.03px] px-[8px] py-[4px] rounded-[33554400px] top-0 w-[76.234px]" data-name="Text">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#364153] text-[12px]">Anti-Aging</p>
    </div>
  );
}

function Container202() {
  return (
    <div className="absolute h-[24px] left-[20px] top-[156px] w-[314.328px]" data-name="Container">
      <Text32 />
      <Text33 />
    </div>
  );
}

function Icon40() {
  return (
    <div className="absolute left-[110.11px] size-[16px] top-[10px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p9d0d100} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button12() {
  return (
    <div className="absolute bg-[#155dfc] h-[36px] left-[20px] rounded-[10px] top-[196px] w-[314.328px]" data-name="Button">
      <Icon40 />
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[169.11px] not-italic text-[14px] text-center text-white top-[8px] tracking-[0.1296px]">Directions</p>
    </div>
  );
}

function Container195() {
  return (
    <div className="absolute bg-white border-2 border-[#e5e7eb] border-solid h-[256px] left-[374.33px] rounded-[14px] top-[272px] w-[358.328px]" data-name="Container">
      <Container196 />
      <Heading19 />
      <Container199 />
      <Container202 />
      <Button12 />
    </div>
  );
}

function Icon41() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g clipPath="url(#clip0_1_914)" id="Icon">
          <path d={svgPaths.p3b43bb80} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p1d7f0000} id="Vector_2" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p2b722f80} id="Vector_3" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33333 5H11.6667" id="Vector_4" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33331 8.33301H11.6666" id="Vector_5" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33331 11.667H11.6666" id="Vector_6" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M8.33333 15H11.6667" id="Vector_7" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
        <defs>
          <clipPath id="clip0_1_914">
            <rect fill="white" height="20" width="20" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container205() {
  return (
    <div className="bg-[#dbeafe] relative rounded-[10px] shrink-0 size-[40px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon41 />
      </div>
    </div>
  );
}

function Container206() {
  return (
    <div className="bg-[#dbeafe] h-[24px] relative rounded-[33554400px] shrink-0 w-[79.875px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start px-[8px] py-[4px] relative size-full">
        <p className="font-['Inter:Bold',sans-serif] font-bold leading-[16px] not-italic relative shrink-0 text-[#1447e6] text-[12px]">CERTIFIED</p>
      </div>
    </div>
  );
}

function Container204() {
  return (
    <div className="absolute content-stretch flex h-[40px] items-start justify-between left-[20px] top-[20px] w-[314.344px]" data-name="Container">
      <Container205 />
      <Container206 />
    </div>
  );
}

function Heading20() {
  return (
    <div className="absolute h-[20px] left-[20px] top-[72px] w-[314.344px]" data-name="Heading 3">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[20px] left-0 not-italic text-[#101828] text-[14px] top-0 tracking-[-0.2904px]">S-Mart Anti-aging Wellness</p>
    </div>
  );
}

function Icon42() {
  return (
    <div className="absolute left-0 size-[14px] top-[2px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Icon">
          <path d={svgPaths.p4623500} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d={svgPaths.pbd96b00} id="Vector_2" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
      </svg>
    </div>
  );
}

function Text34() {
  return (
    <div className="absolute content-stretch flex h-[16px] items-start left-[22px] top-0 w-[48.656px]" data-name="Text">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#4a5565] text-[12px]">Bangkok</p>
    </div>
  );
}

function Container208() {
  return (
    <div className="h-[16px] relative shrink-0 w-full" data-name="Container">
      <Icon42 />
      <Text34 />
    </div>
  );
}

function Icon43() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g clipPath="url(#clip0_1_853)" id="Icon">
          <path d={svgPaths.p11235db0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d="M7 3.5V7L9.33333 8.16667" id="Vector_2" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
        <defs>
          <clipPath id="clip0_1_853">
            <rect fill="white" height="14" width="14" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text35() {
  return (
    <div className="h-[16px] relative shrink-0 w-[125.156px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#4a5565] text-[12px]">Daily: 09:00-19:00</p>
      </div>
    </div>
  );
}

function Container209() {
  return (
    <div className="content-stretch flex gap-[8px] h-[16px] items-center relative shrink-0 w-full" data-name="Container">
      <Icon43 />
      <Text35 />
    </div>
  );
}

function Container207() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[40px] items-start left-[20px] top-[100px] w-[314.344px]" data-name="Container">
      <Container208 />
      <Container209 />
    </div>
  );
}

function Text36() {
  return (
    <div className="absolute bg-[#f3f4f6] content-stretch flex h-[24px] items-start left-0 px-[8px] py-[4px] rounded-[33554400px] top-0 w-[76.234px]" data-name="Text">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#364153] text-[12px]">Anti-Aging</p>
    </div>
  );
}

function Text37() {
  return (
    <div className="absolute bg-[#f3f4f6] content-stretch flex h-[24px] items-start left-[80.23px] px-[8px] py-[4px] rounded-[33554400px] top-0 w-[123.969px]" data-name="Text">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#364153] text-[12px]">Wellness Programs</p>
    </div>
  );
}

function Container210() {
  return (
    <div className="absolute h-[24px] left-[20px] top-[156px] w-[314.344px]" data-name="Container">
      <Text36 />
      <Text37 />
    </div>
  );
}

function Icon44() {
  return (
    <div className="absolute left-[110.13px] size-[16px] top-[10px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p9d0d100} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button13() {
  return (
    <div className="absolute bg-[#155dfc] h-[36px] left-[20px] rounded-[10px] top-[196px] w-[314.344px]" data-name="Button">
      <Icon44 />
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[169.13px] not-italic text-[14px] text-center text-white top-[8px] tracking-[0.1296px]">Directions</p>
    </div>
  );
}

function Container203() {
  return (
    <div className="absolute bg-white border-2 border-[#e5e7eb] border-solid h-[256px] left-[748.66px] rounded-[14px] top-[272px] w-[358.344px]" data-name="Container">
      <Container204 />
      <Heading20 />
      <Container207 />
      <Container210 />
      <Button13 />
    </div>
  );
}

function Container162() {
  return (
    <div className="h-[528px] relative shrink-0 w-full" data-name="Container">
      <Container163 />
      <Container171 />
      <Container179 />
      <Container187 />
      <Container195 />
      <Container203 />
    </div>
  );
}

function Container212() {
  return <div className="absolute bg-[rgba(255,255,255,0.1)] blur-[64px] left-[915px] rounded-[33554400px] size-[192px] top-0" data-name="Container" />;
}

function Heading21() {
  return (
    <div className="absolute h-[32px] left-0 top-0 w-[1043px]" data-name="Heading 3">
      <p className="-translate-x-1/2 absolute font-['Inter:Bold',sans-serif] font-bold leading-[32px] left-[521.41px] not-italic text-[24px] text-center text-white top-0 tracking-[-0.1697px]">Become an re:H Partner</p>
    </div>
  );
}

function Paragraph18() {
  return (
    <div className="absolute h-[48px] left-[215px] top-[48.5px] w-[799px]" data-name="Paragraph">
      <p className="-translate-x-1/2 absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-[305px] not-italic text-[#dbeafe] text-[16px] text-center top-[-12px] tracking-[-0.3125px] w-[702px] whitespace-pre-wrap">{`Join Thailand's leading network of aesthetic clinics offering precision SSCM technology`}</p>
    </div>
  );
}

function Button14() {
  return (
    <div className="absolute bg-white h-[48px] left-[428px] rounded-[10px] shadow-[0px_10px_15px_0px_rgba(0,0,0,0.1),0px_4px_6px_0px_rgba(0,0,0,0.1)] top-[80.5px] w-[187.016px]" data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[24px] left-[94px] not-italic text-[#155dfc] text-[16px] text-center top-[12px] tracking-[0.0075px]">Partner Enquiry</p>
    </div>
  );
}

function Container213() {
  return (
    <div className="absolute h-[160px] left-[32px] top-[32px] w-[1043px]" data-name="Container">
      <Heading21 />
      <Paragraph18 />
      <Button14 />
    </div>
  );
}

function Container211() {
  return (
    <div className="bg-gradient-to-r from-[#155dfc] h-[193px] overflow-clip relative rounded-[16px] shadow-[0px_25px_50px_-12px_rgba(0,0,0,0.25)] shrink-0 to-[#193cb8] w-full" data-name="Container">
      <Container212 />
      <Container213 />
    </div>
  );
}

function Container156() {
  return (
    <div className="h-[1090px] relative shrink-0 w-full" data-name="Container">
      <div className="content-stretch flex flex-col gap-[32px] items-start px-[32px] relative size-full">
        <Container157 />
        <Container159 />
        <Container162 />
        <Container211 />
      </div>
    </div>
  );
}

function FindClinic() {
  return (
    <div className="bg-gradient-to-b content-stretch flex flex-col from-white h-[1120px] items-start overflow-clip pt-[30px] relative shrink-0 to-white via-1/2 via-[#f9fafb] w-full" data-name="FindClinic">
      <Container156 />
    </div>
  );
}

function Container214() {
  return <div className="absolute h-[1009px] left-0 opacity-3 top-[-28.5px] w-[1171px]" data-name="Container" style={{ backgroundImage: "url(\'data:image/svg+xml;utf8,<svg viewBox=\\'0 0 1171 1009\\' xmlns=\\'http://www.w3.org/2000/svg\\' preserveAspectRatio=\\'none\\'><rect x=\\'0\\' y=\\'0\\' height=\\'100%\\' width=\\'100%\\' fill=\\'url(%23grad)\\' opacity=\\'1\\'/><defs><radialGradient id=\\'grad\\' gradientUnits=\\'userSpaceOnUse\\' cx=\\'0\\' cy=\\'0\\' r=\\'10\\' gradientTransform=\\'matrix(0 -69.443 -85.204 0 585.5 504.5)\\'><stop stop-color=\\'rgba(255,255,255,1)\\' offset=\\'0.00085397\\'/><stop stop-color=\\'rgba(191,191,191,0.75)\\' offset=\\'0.00064048\\'/><stop stop-color=\\'rgba(128,128,128,0.5)\\' offset=\\'0.00042699\\'/><stop stop-color=\\'rgba(64,64,64,0.25)\\' offset=\\'0.00021349\\'/><stop stop-color=\\'rgba(0,0,0,0)\\' offset=\\'0\\'/></radialGradient></defs></svg>\')" }} />;
}

function Container215() {
  return <div className="absolute blur-[64px] left-0 rounded-[33554400px] size-[500px] top-[738px]" data-name="Container" style={{ backgroundImage: "linear-gradient(135deg, rgba(201, 169, 98, 0.1) 0%, rgba(0, 0, 0, 0) 100%)" }} />;
}

function Text38() {
  return (
    <div className="absolute content-stretch flex h-[71px] items-start left-[204.95px] top-[63px] w-[358.078px]" data-name="Text">
      <p className="bg-clip-text font-['Inter:Bold',sans-serif] font-bold leading-[66px] not-italic relative shrink-0 text-[60px] text-[rgba(0,0,0,0)] text-center tracking-[-1.2363px]" style={{ backgroundImage: "linear-gradient(90deg, rgba(0, 0, 0, 0) 0%, rgba(0, 0, 0, 0) 100%), linear-gradient(90deg, rgb(20, 71, 230) 0%, rgba(21, 93, 252, 0.7) 50%, rgba(43, 127, 255, 0.5) 100%)", WebkitTextFillColor: "transparent" }}>
        Clinical Demo
      </p>
    </div>
  );
}

function Heading22() {
  return (
    <div className="absolute h-[132px] left-0 top-[62px] w-[768px]" data-name="Heading 2">
      <p className="-translate-x-1/2 absolute font-['Inter:Bold',sans-serif] font-bold leading-[66px] left-[383.66px] not-italic text-[60px] text-[rgba(43,127,255,0.5)] text-center top-0 tracking-[-1.2363px]">Request a</p>
      <Text38 />
    </div>
  );
}

function Container217() {
  return (
    <div className="absolute h-[283px] left-[200.5px] top-[-1px] w-[768px]" data-name="Container">
      <Heading22 />
    </div>
  );
}

function Heading23() {
  return (
    <div className="h-[32px] relative shrink-0 w-full" data-name="Heading 3">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[32px] left-0 not-italic text-[#0a0a0a] text-[24px] text-left top-0 tracking-[-0.5297px]">Request a Clinical Demo</p>
    </div>
  );
}

function Paragraph19() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Light',sans-serif] font-light leading-[24px] left-0 not-italic text-[#4a5565] text-[16px] text-left top-0 tracking-[-0.3125px]">{`We'll contact you within 24 hours`}</p>
    </div>
  );
}

function TextInput1() {
  return (
    <div className="absolute h-[50px] left-0 rounded-[14px] top-0 w-[249.188px]" data-name="Text Input">
      <div className="content-stretch flex items-center overflow-clip px-[20px] py-[14px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[normal] not-italic relative shrink-0 text-[14px] text-[rgba(10,10,10,0.5)] text-left tracking-[-0.1504px]">Full Name *</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[#d1d5dc] border-solid inset-0 pointer-events-none rounded-[14px]" />
    </div>
  );
}

function TextInput2() {
  return (
    <div className="absolute h-[50px] left-[269.19px] rounded-[14px] top-0 w-[249.203px]" data-name="Text Input">
      <div className="content-stretch flex items-center overflow-clip px-[20px] py-[14px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[normal] not-italic relative shrink-0 text-[14px] text-[rgba(10,10,10,0.5)] text-left tracking-[-0.1504px]">Clinic Name *</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[#d1d5dc] border-solid inset-0 pointer-events-none rounded-[14px]" />
    </div>
  );
}

function Container221() {
  return (
    <div className="absolute h-[50px] left-0 top-0 w-[518.391px]" data-name="Container">
      <TextInput1 />
      <TextInput2 />
    </div>
  );
}

function EmailInput() {
  return (
    <div className="absolute h-[50px] left-0 rounded-[14px] top-0 w-[249.188px]" data-name="Email Input">
      <div className="content-stretch flex items-center overflow-clip px-[20px] py-[14px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[normal] not-italic relative shrink-0 text-[14px] text-[rgba(10,10,10,0.5)] text-left tracking-[-0.1504px]">Email Address *</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[#d1d5dc] border-solid inset-0 pointer-events-none rounded-[14px]" />
    </div>
  );
}

function PhoneInput() {
  return (
    <div className="absolute h-[50px] left-[269.19px] rounded-[14px] top-0 w-[249.203px]" data-name="Phone Input">
      <div className="content-stretch flex items-center overflow-clip px-[20px] py-[14px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[normal] not-italic relative shrink-0 text-[14px] text-[rgba(10,10,10,0.5)] text-left tracking-[-0.1504px]">Phone Number *</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[#d1d5dc] border-solid inset-0 pointer-events-none rounded-[14px]" />
    </div>
  );
}

function Container222() {
  return (
    <div className="absolute h-[50px] left-0 top-[70px] w-[518.391px]" data-name="Container">
      <EmailInput />
      <PhoneInput />
    </div>
  );
}

function Container223() {
  return <div className="absolute h-[49px] left-0 top-[140px] w-[518.391px]" data-name="Container" />;
}

function TextArea() {
  return (
    <div className="absolute h-[90px] left-0 rounded-[14px] top-[149px] w-[518.391px]" data-name="Text Area">
      <div className="content-stretch flex items-start overflow-clip px-[20px] py-[14px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[14px] text-[rgba(10,10,10,0.5)] text-left tracking-[-0.1504px]">Message / Questions (Optional)</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[#d1d5dc] border-solid inset-0 pointer-events-none rounded-[14px]" />
    </div>
  );
}

function Container224() {
  return <div className="absolute bg-gradient-to-r from-[rgba(0,0,0,0)] h-[52px] left-[-518.39px] to-[rgba(0,0,0,0)] top-0 via-1/2 via-[rgba(255,255,255,0.2)] w-[518.391px]" data-name="Container" />;
}

function Icon45() {
  return (
    <div className="absolute left-[337.61px] size-[18px] top-px" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="Icon">
          <path d="M3.75 9H14.25" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M9 3.75L14.25 9L9 14.25" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Text39() {
  return (
    <div className="absolute h-[20px] left-[24px] top-[16px] w-[470.391px]" data-name="Text">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[220.28px] not-italic text-[14px] text-center text-white top-0 tracking-[0.9696px] uppercase">Schedule Clinical Demo</p>
      <Icon45 />
    </div>
  );
}

function Button15() {
  return (
    <div className="absolute bg-gradient-to-b from-[#1447e6] h-[52px] left-0 overflow-clip rounded-[14px] to-[#1a1a1a] top-[265px] w-[518.391px]" data-name="Button">
      <Container224 />
      <Text39 />
    </div>
  );
}

function Container220() {
  return (
    <div className="h-[413px] relative shrink-0 w-full" data-name="Container">
      <Container221 />
      <Container222 />
      <Container223 />
      <TextArea />
      <Button15 />
    </div>
  );
}

function Container219() {
  return (
    <div className="absolute bg-[#eff6ff] content-stretch flex flex-col gap-[8px] h-[575px] items-start left-0 pt-[48px] px-[48px] top-[0.5px] w-[614px]" data-name="Container">
      <Heading23 />
      <Paragraph19 />
      <Container220 />
    </div>
  );
}

function Container226() {
  return <div className="absolute bg-[rgba(255,255,255,0.1)] blur-[64px] left-[249.61px] rounded-[33554400px] size-[160px] top-0" data-name="Container" />;
}

function Heading24() {
  return (
    <div className="h-[28px] relative shrink-0 w-full" data-name="Heading 4">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[28px] left-0 not-italic text-[20px] text-left text-white top-0 tracking-[-0.9492px]">{`What's Included:`}</p>
    </div>
  );
}

function Icon46() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p1aae36c0} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p1dd4fd00} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function Container230() {
  return (
    <div className="bg-[rgba(43,127,255,0.5)] relative rounded-[14px] shrink-0 size-[32px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon46 />
      </div>
    </div>
  );
}

function Container232() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[20px] left-0 not-italic text-[14px] text-left text-white top-0 tracking-[-0.1504px]">45-Min On-Site Demo</p>
    </div>
  );
}

function Container233() {
  return (
    <div className="h-[19.5px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[19.5px] left-0 not-italic text-[#dbeafe] text-[12px] text-left top-0">Personalized at your clinic</p>
    </div>
  );
}

function Container231() {
  return (
    <div className="h-[43.5px] relative shrink-0 w-[147.781px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[4px] items-start relative size-full">
        <Container232 />
        <Container233 />
      </div>
    </div>
  );
}

function Container229() {
  return (
    <div className="content-stretch flex gap-[16px] h-[43.5px] items-start relative shrink-0 w-full" data-name="Container">
      <Container230 />
      <Container231 />
    </div>
  );
}

function Icon47() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p37f49070} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function Container235() {
  return (
    <div className="bg-[rgba(43,127,255,0.5)] relative rounded-[14px] shrink-0 size-[32px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon47 />
      </div>
    </div>
  );
}

function Container237() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[20px] left-0 not-italic text-[14px] text-left text-white top-0 tracking-[-0.1504px]">Live Technology Showcase</p>
    </div>
  );
}

function Container238() {
  return (
    <div className="h-[19.5px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[19.5px] left-0 not-italic text-[#dbeafe] text-[12px] text-left top-0">Real-time precision testing</p>
    </div>
  );
}

function Container236() {
  return (
    <div className="h-[43.5px] relative shrink-0 w-[180.75px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[4px] items-start relative size-full">
        <Container237 />
        <Container238 />
      </div>
    </div>
  );
}

function Container234() {
  return (
    <div className="content-stretch flex gap-[16px] h-[43.5px] items-start relative shrink-0 w-full" data-name="Container">
      <Container235 />
      <Container236 />
    </div>
  );
}

function Icon48() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g clipPath="url(#clip0_1_911)" id="Icon">
          <path d={svgPaths.p209c4100} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
        <defs>
          <clipPath id="clip0_1_911">
            <rect fill="white" height="16" width="16" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container240() {
  return (
    <div className="bg-[rgba(43,127,255,0.5)] relative rounded-[14px] shrink-0 size-[32px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon48 />
      </div>
    </div>
  );
}

function Container242() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[20px] left-0 not-italic text-[14px] text-left text-white top-0 tracking-[-0.1504px]">Clinical Protocol Review</p>
    </div>
  );
}

function Container243() {
  return (
    <div className="h-[19.5px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[19.5px] left-0 not-italic text-[#dbeafe] text-[12px] text-left top-0">Tailored recommendations</p>
    </div>
  );
}

function Container241() {
  return (
    <div className="h-[43.5px] relative shrink-0 w-[161.297px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[4px] items-start relative size-full">
        <Container242 />
        <Container243 />
      </div>
    </div>
  );
}

function Container239() {
  return (
    <div className="content-stretch flex gap-[16px] h-[43.5px] items-start relative shrink-0 w-full" data-name="Container">
      <Container240 />
      <Container241 />
    </div>
  );
}

function Container228() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] h-[178.5px] items-start relative shrink-0 w-full" data-name="Container">
      <Container229 />
      <Container234 />
      <Container239 />
    </div>
  );
}

function Icon49() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g clipPath="url(#clip0_1_843)" id="Icon">
          <path d={svgPaths.p3b83c880} id="Vector" stroke="var(--stroke-0, #8EC5FF)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
        <defs>
          <clipPath id="clip0_1_843">
            <rect fill="white" height="16" width="16" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text40() {
  return (
    <div className="h-[16px] relative shrink-0 w-[123px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#dbeafe] text-[12px] text-left">+66 61 361 4599</p>
      </div>
    </div>
  );
}

function Container245() {
  return (
    <div className="content-stretch flex gap-[12px] h-[16px] items-center relative shrink-0 w-full" data-name="Container">
      <Icon49 />
      <Text40 />
    </div>
  );
}

function Icon50() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p124eba00} id="Vector" stroke="var(--stroke-0, #8EC5FF)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p28233b60} id="Vector_2" stroke="var(--stroke-0, #8EC5FF)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function Text41() {
  return (
    <div className="h-[16px] relative shrink-0 w-[123.078px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#dbeafe] text-[12px] text-left">sales@jnacorporation.com</p>
      </div>
    </div>
  );
}

function Container246() {
  return (
    <div className="content-stretch flex gap-[12px] h-[16px] items-center relative shrink-0 w-full" data-name="Container">
      <Icon50 />
      <Text41 />
    </div>
  );
}

function Icon51() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p321f4d00} id="Vector" stroke="var(--stroke-0, #8EC5FF)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p3a5e5a00} id="Vector_2" stroke="var(--stroke-0, #8EC5FF)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function Text42() {
  return (
    <div className="h-[16px] relative shrink-0 w-[103.875px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#dbeafe] text-[12px] text-left">Bangkok, Thailand</p>
      </div>
    </div>
  );
}

function Container247() {
  return (
    <div className="content-stretch flex gap-[12px] h-[16px] items-center relative shrink-0 w-full" data-name="Container">
      <Icon51 />
      <Text42 />
    </div>
  );
}

function Container244() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] h-[97px] items-start pt-[25px] relative shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#2b7fff] border-solid border-t inset-0 pointer-events-none" />
      <Container245 />
      <Container246 />
      <Container247 />
    </div>
  );
}

function Container227() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[32px] h-[375.5px] items-start left-[48px] top-[48px] w-[313.609px]" data-name="Container">
      <Heading24 />
      <Container228 />
      <Container244 />
    </div>
  );
}

function Container225() {
  return (
    <div className="absolute h-[605px] left-[614.39px] overflow-clip top-0 w-[409.609px]" data-name="Container" style={{ backgroundImage: "linear-gradient(124.1deg, rgb(21, 93, 252) 0%, rgb(25, 60, 184) 100%)" }}>
      <Container226 />
      <Container227 />
    </div>
  );
}

function Container218() {
  return (
    <div className="absolute bg-white cursor-pointer h-[466px] left-[73px] overflow-clip rounded-[24px] shadow-[0px_25px_50px_-12px_rgba(0,0,0,0.25)] top-[245px] w-[986px]" data-name="Container" role="button" tabIndex="0">
      <Container219 />
      <Container225 />
    </div>
  );
}

function Container216() {
  return (
    <div className="absolute bg-white border border-black border-solid h-[1157px] left-[-14px] top-[-40px] w-[1230px]" data-name="Container">
      <Container217 />
      <Container218 />
    </div>
  );
}

function FinalCta() {
  return (
    <button className="bg-gradient-to-b block cursor-pointer from-[#f9fafb] h-[740px] overflow-clip relative shrink-0 to-[#1447e6] via-1/2 via-[rgba(43,127,255,0.5)] w-full" data-name="FinalCTA">
      <Container214 />
      <Container215 />
      <Container216 />
    </button>
  );
}

function ImageReHThailand() {
  return (
    <div className="absolute h-[48px] left-0 opacity-90 top-0 w-[151px]" data-name="Image (re:H Thailand)">
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImageReHThailand} />
    </div>
  );
}

function Paragraph20() {
  return (
    <div className="absolute h-[78px] left-0 top-[64px] w-[410.578px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Light',sans-serif] font-light leading-[26px] left-0 not-italic text-[16px] text-left text-white top-0 tracking-[-0.3125px] w-[431px] whitespace-pre-wrap">Precision microneedling technology for medical aesthetics. TFDA certified, ISO 13485:2016 quality assured.</p>
    </div>
  );
}

function Icon52() {
  return (
    <div className="absolute left-0 size-[18px] top-[2px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="Icon">
          <path d={svgPaths.p625a980} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p18c84c80} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Text43() {
  return (
    <div className="absolute h-[20px] left-[34px] top-0 w-[338.891px]" data-name="Text">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[14px] text-left text-white top-0 tracking-[-0.1504px]">Distributed exclusively by JNA Corporation, Thailand</p>
    </div>
  );
}

function Container252() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Container">
      <Icon52 />
      <Text43 />
    </div>
  );
}

function Icon53() {
  return (
    <div className="relative shrink-0 size-[18px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="Icon">
          <path d={svgPaths.p1b122e80} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p17a68100} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Link() {
  return (
    <div className="h-[20px] relative shrink-0 w-[140.578px]" data-name="Link">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[14px] text-left text-white top-0 tracking-[-0.1504px]">info@rehthailand.com</p>
      </div>
    </div>
  );
}

function Container253() {
  return (
    <div className="content-stretch flex gap-[16px] h-[20px] items-center relative shrink-0 w-full" data-name="Container">
      <Icon53 />
      <Link />
    </div>
  );
}

function Icon54() {
  return (
    <div className="relative shrink-0 size-[18px]" data-name="Icon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g clipPath="url(#clip0_1_963)" id="Icon">
          <path d={svgPaths.p32db8200} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
        <defs>
          <clipPath id="clip0_1_963">
            <rect fill="white" height="18" width="18" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Link1() {
  return (
    <div className="h-[20px] relative shrink-0 w-[140.781px]" data-name="Link">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[14px] text-left text-white top-0 tracking-[-0.1504px]">+66 (0)X XXXX XXXX</p>
      </div>
    </div>
  );
}

function Container254() {
  return (
    <div className="content-stretch flex gap-[16px] h-[20px] items-center relative shrink-0 w-full" data-name="Container">
      <Icon54 />
      <Link1 />
    </div>
  );
}

function Container251() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[16px] h-[92px] items-start left-0 top-[174px] w-[410.578px]" data-name="Container">
      <Container252 />
      <Container253 />
      <Container254 />
    </div>
  );
}

function Container250() {
  return (
    <div className="absolute h-[266px] left-0 top-0 w-[410.578px]" data-name="Container">
      <ImageReHThailand />
      <Paragraph20 />
      <Container251 />
    </div>
  );
}

function Heading25() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Heading 3">
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[20px] left-0 not-italic text-[14px] text-left text-white top-0 tracking-[1.2496px] uppercase">Quick Links</p>
    </div>
  );
}

function Text44() {
  return <div className="absolute bg-white h-px left-0 top-[9.5px] w-0" data-name="Text" />;
}

function Button16() {
  return (
    <div className="absolute h-[20px] left-0 top-0 w-[128.797px]" data-name="Button">
      <Text44 />
      <p className="absolute font-['Inter:Light',sans-serif] font-light leading-[20px] left-[8px] not-italic text-[14px] text-left text-white top-0 tracking-[0.1296px]">SSCM Technology</p>
    </div>
  );
}

function ListItem() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="List Item">
      <Button16 />
    </div>
  );
}

function Text45() {
  return <div className="absolute bg-white h-px left-0 top-[9.5px] w-0" data-name="Text" />;
}

function Button17() {
  return (
    <div className="absolute h-[20px] left-0 top-0 w-[77.875px]" data-name="Button">
      <Text45 />
      <p className="absolute font-['Inter:Light',sans-serif] font-light leading-[20px] left-[8px] not-italic text-[14px] text-left text-white top-0 tracking-[0.1296px]">For Clinics</p>
    </div>
  );
}

function ListItem1() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="List Item">
      <Button17 />
    </div>
  );
}

function Text46() {
  return <div className="absolute bg-white h-px left-0 top-[9.5px] w-0" data-name="Text" />;
}

function Button18() {
  return (
    <div className="absolute h-[20px] left-0 top-0 w-[120.609px]" data-name="Button">
      <Text46 />
      <p className="absolute font-['Inter:Light',sans-serif] font-light leading-[20px] left-[8px] not-italic text-[14px] text-left text-white top-0 tracking-[0.1296px]">Clinical Evidence</p>
    </div>
  );
}

function ListItem2() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="List Item">
      <Button18 />
    </div>
  );
}

function Text47() {
  return <div className="absolute bg-white h-px left-0 top-[9.5px] w-0" data-name="Text" />;
}

function Button19() {
  return (
    <div className="absolute h-[20px] left-0 top-0 w-[88.938px]" data-name="Button">
      <Text47 />
      <p className="absolute font-['Inter:Light',sans-serif] font-light leading-[20px] left-[8px] not-italic text-[14px] text-left text-white top-0 tracking-[0.1296px]">Find a Clinic</p>
    </div>
  );
}

function ListItem3() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="List Item">
      <Button19 />
    </div>
  );
}

function Text48() {
  return <div className="absolute bg-white h-px left-0 top-[9.5px] w-0" data-name="Text" />;
}

function Button20() {
  return (
    <div className="absolute h-[20px] left-0 top-0 w-[69.563px]" data-name="Button">
      <Text48 />
      <p className="absolute font-['Inter:Light',sans-serif] font-light leading-[20px] left-[8px] not-italic text-[14px] text-left text-white top-0 tracking-[0.1296px]">About Us</p>
    </div>
  );
}

function ListItem4() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="List Item">
      <Button20 />
    </div>
  );
}

function List1() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] h-[148px] items-start relative shrink-0 w-full" data-name="List">
      <ListItem />
      <ListItem1 />
      <ListItem2 />
      <ListItem3 />
      <ListItem4 />
    </div>
  );
}

function Container257() {
  return <div className="absolute bg-gradient-to-r from-[rgba(10,10,10,0.5)] h-[44px] left-[-312.66px] to-[rgba(10,10,10,0.5)] top-px via-1/2 via-white w-[313.656px]" data-name="Container" />;
}

function Text49() {
  return (
    <div className="absolute content-stretch flex h-[17px] items-start left-[0.67px] top-[14px] w-[186.078px]" data-name="Text">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[20px] not-italic relative shrink-0 text-[14px] text-center text-white tracking-[0.9696px] uppercase w-[220px] whitespace-pre-wrap">Request Information</p>
    </div>
  );
}

function Button21() {
  return (
    <div className="bg-[rgba(255,255,255,0.05)] h-[46px] relative shrink-0 w-full" data-name="Button">
      <div className="overflow-clip relative rounded-[inherit] size-full">
        <Container257 />
        <Text49 />
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(255,255,255,0.1)] border-solid inset-0 pointer-events-none" />
    </div>
  );
}

function Container256() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] h-[266px] items-start relative shrink-0 w-[220.75px]" data-name="Container">
      <Heading25 />
      <List1 />
      <Button21 />
    </div>
  );
}

function List() {
  return (
    <div className="content-stretch flex flex-col h-[116px] items-start relative shrink-0 w-full" data-name="List">
      <Container256 />
    </div>
  );
}

function Container255() {
  return (
    <div className="absolute content-stretch flex flex-col h-[266px] items-start left-[759.33px] top-0 w-[315.656px]" data-name="Container">
      <List />
    </div>
  );
}

function Container249() {
  return (
    <div className="h-[266px] relative shrink-0 w-full" data-name="Container">
      <Container250 />
      <Container255 />
    </div>
  );
}

function Container259() {
  return <div className="bg-gradient-to-r from-[rgba(0,0,0,0)] h-px shrink-0 to-[rgba(0,0,0,0)] via-1/2 via-[rgba(255,255,255,0.1)] w-full" data-name="Container" />;
}

function Paragraph21() {
  return (
    <div className="h-[16px] relative shrink-0 w-[248.5px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[12px] text-left text-white tracking-[0.3px]">© 2026 re:H Thailand. All rights reserved.</p>
      </div>
    </div>
  );
}

function Text51() {
  return <div className="absolute bg-white left-0 rounded-[33554400px] size-[4px] top-[6px]" data-name="Text" />;
}

function Text50() {
  return (
    <div className="absolute h-[16px] left-0 top-0 w-[144px]" data-name="Text">
      <Text51 />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-[12px] not-italic text-[12px] text-left text-white top-0">TFDA: 66-1-02-0-0018</p>
    </div>
  );
}

function Text52() {
  return (
    <div className="absolute content-stretch flex h-[16px] items-start left-[160px] top-0 w-[5.672px]" data-name="Text">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[12px] text-left text-white">•</p>
    </div>
  );
}

function Text54() {
  return <div className="absolute bg-white left-0 rounded-[33554400px] size-[4px] top-[6px]" data-name="Text" />;
}

function Text53() {
  return (
    <div className="absolute h-[16px] left-[181.67px] top-0 w-[103.016px]" data-name="Text">
      <Text54 />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-[12px] not-italic text-[12px] text-left text-white top-0">ISO 13485:2016</p>
    </div>
  );
}

function Text55() {
  return (
    <div className="absolute content-stretch flex h-[16px] items-start left-[300.69px] top-0 w-[5.672px]" data-name="Text">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[12px] text-left text-white">•</p>
    </div>
  );
}

function Text57() {
  return <div className="absolute bg-white left-0 rounded-[33554400px] size-[4px] top-[6px]" data-name="Text" />;
}

function Text56() {
  return (
    <div className="absolute h-[16px] left-[322.36px] top-0 w-[97.438px]" data-name="Text">
      <Text57 />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-[12px] not-italic text-[12px] text-left text-white top-0">Korean Patents</p>
    </div>
  );
}

function Container261() {
  return (
    <div className="h-[16px] relative shrink-0 w-[419.797px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Text50 />
        <Text52 />
        <Text53 />
        <Text55 />
        <Text56 />
      </div>
    </div>
  );
}

function Container260() {
  return (
    <div className="content-stretch flex h-[16px] items-center justify-between relative shrink-0 w-full" data-name="Container">
      <Paragraph21 />
      <Container261 />
    </div>
  );
}

function Container258() {
  return (
    <div className="content-stretch flex flex-col gap-[31px] h-[48px] items-start relative shrink-0 w-full" data-name="Container">
      <Container259 />
      <Container260 />
    </div>
  );
}

function Container248() {
  return (
    <div className="absolute bg-[rgba(43,127,255,0.5)] content-stretch flex flex-col gap-[15px] h-[436px] items-start left-0 pt-[80px] px-[48px] top-[0.5px] w-[1171px]" data-name="Container">
      <Container249 />
      <Container258 />
    </div>
  );
}

function Container262() {
  return <div className="absolute bg-gradient-to-r from-[rgba(0,0,0,0)] h-px left-0 to-[rgba(0,0,0,0)] top-0 via-1/2 via-[rgba(201,169,98,0.3)] w-[1171px]" data-name="Container" />;
}

function Footer() {
  return (
    <button className="bg-gradient-to-b block cursor-pointer from-[#1447e6] h-[436px] relative shrink-0 to-[rgba(43,127,255,0.5)] w-full" data-name="Footer">
      <Container248 />
      <Container262 />
    </button>
  );
}

function App() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col items-start left-0 top-[-47px] w-[1171px]" data-name="App">
      <Hero />
      <WhatIsSscm />
      <OfficialVideo />
      <ClinicalEvidence />
      <FindClinic />
      <FinalCta />
      <Footer />
    </div>
  );
}

function ImageReHThailand1() {
  return (
    <div className="flex-[1_0_0] h-[36px] min-h-px min-w-px relative" data-name="Image (re:H Thailand)">
      <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImageReHThailand} />
    </div>
  );
}

function Link2() {
  return (
    <div className="h-[36px] relative shrink-0 w-[115.156px]" data-name="Link">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center relative size-full">
        <ImageReHThailand1 />
      </div>
    </div>
  );
}

function Text58() {
  return <div className="absolute bg-gradient-to-b from-[#c9a962] h-px left-0 to-[#e5d4a6] top-[23px] w-0" data-name="Text" />;
}

function Button22() {
  return (
    <div className="absolute h-[20px] left-0 top-[12px] w-[79.688px]" data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[40px] not-italic text-[#364153] text-[14px] text-center top-0 tracking-[0.1996px]">Technology</p>
      <Text58 />
    </div>
  );
}

function Text59() {
  return <div className="absolute bg-gradient-to-b from-[#c9a962] h-px left-0 to-[#e5d4a6] top-[23px] w-0" data-name="Text" />;
}

function Button23() {
  return (
    <div className="absolute h-[20px] left-[127.69px] top-[12px] w-[73.188px]" data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[37px] not-italic text-[#364153] text-[14px] text-center top-0 tracking-[0.1996px]">For Clinics</p>
      <Text59 />
    </div>
  );
}

function Text60() {
  return <div className="absolute bg-gradient-to-b from-[#c9a962] h-px left-0 to-[#e5d4a6] top-[23px] w-0" data-name="Text" />;
}

function Button24() {
  return (
    <div className="absolute h-[20px] left-[248.88px] top-[12px] w-[97px]" data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[48.5px] not-italic text-[#364153] text-[14px] text-center top-0 tracking-[0.1996px]">Clinical Cases</p>
      <Text60 />
    </div>
  );
}

function Text61() {
  return <div className="absolute bg-gradient-to-b from-[#c9a962] h-px left-0 to-[#e5d4a6] top-[23px] w-0" data-name="Text" />;
}

function Button25() {
  return (
    <div className="absolute h-[20px] left-[393.88px] top-[12px] w-[72.453px]" data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[36px] not-italic text-[#364153] text-[14px] text-center top-0 tracking-[0.1996px]">Find Clinic</p>
      <Text61 />
    </div>
  );
}

function Text62() {
  return <div className="absolute bg-gradient-to-b from-[#c9a962] h-px left-0 to-[#e5d4a6] top-[23px] w-0" data-name="Text" />;
}

function Button26() {
  return (
    <div className="absolute h-[20px] left-[514.33px] top-[12px] w-[41.578px]" data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[21px] not-italic text-[#364153] text-[14px] text-center top-0 tracking-[0.1996px]">About</p>
      <Text62 />
    </div>
  );
}

function Container264() {
  return <div className="absolute bg-gradient-to-r from-[rgba(0,0,0,0)] h-[44px] left-[-176.92px] to-[rgba(0,0,0,0)] top-0 via-1/2 via-[rgba(255,255,255,0.2)] w-[176.922px]" data-name="Container" />;
}

function Text63() {
  return (
    <div className="absolute content-stretch flex h-[17px] items-start left-[32px] top-[13px] w-[112.922px]" data-name="Text">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[20px] not-italic relative shrink-0 text-[14px] text-center text-white tracking-[0.5496px]">Schedule Demo</p>
    </div>
  );
}

function Button27() {
  return (
    <div className="absolute bg-gradient-to-b from-[#0a0a0a] h-[44px] left-[603.91px] overflow-clip to-[#1a1a1a] top-0 w-[176.922px]" data-name="Button">
      <Container264 />
      <Text63 />
    </div>
  );
}

function Container263() {
  return (
    <div className="h-[44px] relative shrink-0 w-[780.828px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Button22 />
        <Button23 />
        <Button24 />
        <Button25 />
        <Button26 />
        <Button27 />
      </div>
    </div>
  );
}

function Navigation() {
  return (
    <div className="absolute content-stretch flex h-[96px] items-center justify-between left-[48px] top-[4px] w-[1075px]" data-name="Navigation">
      <Link2 />
      <Container263 />
    </div>
  );
}

export default function ReHThailandWebsite() {
  return (
    <div className="bg-white relative size-full" data-name="reH Thailand Website">
      <App />
      <Navigation />
    </div>
  );
}