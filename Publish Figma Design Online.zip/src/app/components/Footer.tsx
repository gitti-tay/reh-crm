import imgLogo from "figma:asset/1ffbd753ec27789a617aa37d799e86f2761e08d5.png";
import svgPaths from "../../imports/svg-sqg3bg9ea9";

const quickLinks = [
  "SSCM Technology",
  "For Clinics",
  "Clinical Evidence",
  "Find a Clinic",
  "About Us",
];

export function Footer() {
  return (
    <footer id="about" className="bg-gradient-to-b from-[#1447e6] to-[rgba(43,127,255,0.5)] pt-20 pb-8">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-12">
        <div className="flex flex-col lg:flex-row gap-12 lg:gap-20 mb-12">
          {/* Left - Brand */}
          <div className="flex-1">
            <img
              src={imgLogo}
              alt="re:H Thailand"
              className="h-[48px] w-auto object-contain opacity-90 mb-6"
            />
            <p className="font-['Inter',sans-serif] font-light text-[16px] text-white leading-[1.6] tracking-[-0.31px] max-w-[430px] mb-6">
              Precision microneedling technology for medical aesthetics. TFDA certified, ISO 13485:2016 quality assured.
            </p>

            <div className="flex flex-col gap-4">
              <div className="flex items-center gap-3">
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" className="flex-shrink-0">
                  <path d={svgPaths.p625a980} stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
                  <path d={svgPaths.p18c84c80} stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
                </svg>
                <span className="font-['Inter',sans-serif] font-normal text-[14px] text-white tracking-[-0.15px]">
                  Distributed exclusively by JNA Corporation, Thailand
                </span>
              </div>
              <div className="flex items-center gap-3">
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" className="flex-shrink-0">
                  <path d={svgPaths.p1b122e80} stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
                  <path d={svgPaths.p17a68100} stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
                </svg>
                <span className="font-['Inter',sans-serif] font-normal text-[14px] text-white tracking-[-0.15px]">
                  info@rehthailand.com
                </span>
              </div>
              <div className="flex items-center gap-3">
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" className="flex-shrink-0">
                  <path d={svgPaths.p32db8200} stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
                </svg>
                <span className="font-['Inter',sans-serif] font-normal text-[14px] text-white tracking-[-0.15px]">
                  +66 (0)X XXXX XXXX
                </span>
              </div>
            </div>
          </div>

          {/* Right - Quick Links */}
          <div className="lg:w-[300px]">
            <h4 className="font-['Inter',sans-serif] font-semibold text-[14px] text-white tracking-[1.25px] uppercase mb-6">
              Quick Links
            </h4>
            <ul className="flex flex-col gap-3 mb-6">
              {quickLinks.map((link) => (
                <li key={link}>
                  <a
                    href="#"
                    className="font-['Inter',sans-serif] font-light text-[14px] text-white tracking-[0.13px] hover:text-[#bedbff] transition-colors"
                  >
                    {link}
                  </a>
                </li>
              ))}
            </ul>
            <button className="w-full bg-white/5 border border-white/10 py-3 font-['Inter',sans-serif] font-medium text-[14px] text-white tracking-[0.97px] uppercase cursor-pointer hover:bg-white/10 transition-colors">
              Request Information
            </button>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="h-px w-full bg-gradient-to-r from-transparent via-white/10 to-transparent mb-6" />
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="font-['Inter',sans-serif] font-normal text-[12px] text-white tracking-[0.3px]">
            © 2026 re:H Thailand. All rights reserved.
          </p>
          <div className="flex flex-wrap items-center gap-3">
            <span className="flex items-center gap-2">
              <span className="w-1 h-1 rounded-full bg-white" />
              <span className="font-['Inter',sans-serif] font-normal text-[12px] text-white">TFDA: 66-1-02-0-0018</span>
            </span>
            <span className="font-['Inter',sans-serif] font-normal text-[12px] text-white">•</span>
            <span className="flex items-center gap-2">
              <span className="w-1 h-1 rounded-full bg-white" />
              <span className="font-['Inter',sans-serif] font-normal text-[12px] text-white">ISO 13485:2016</span>
            </span>
            <span className="font-['Inter',sans-serif] font-normal text-[12px] text-white">•</span>
            <span className="flex items-center gap-2">
              <span className="w-1 h-1 rounded-full bg-white" />
              <span className="font-['Inter',sans-serif] font-normal text-[12px] text-white">Korean Patents</span>
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
