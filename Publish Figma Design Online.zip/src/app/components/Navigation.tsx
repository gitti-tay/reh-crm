import { useState, useEffect } from "react";
import imgLogo from "figma:asset/1ffbd753ec27789a617aa37d799e86f2761e08d5.png";

const navLinks = [
  { label: "Technology", href: "#technology" },
  { label: "For Clinics", href: "#clinics" },
  { label: "Clinical Cases", href: "#evidence" },
  { label: "Find Clinic", href: "#find-clinic" },
  { label: "About", href: "#about" },
];

export function Navigation() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handler);
    return () => window.removeEventListener("scroll", handler);
  }, []);

  const handleNavClick = (href: string) => {
    setMobileOpen(false);
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-white/95 backdrop-blur-md shadow-sm"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-[1200px] mx-auto px-6 lg:px-12 flex items-center justify-between h-[72px] lg:h-[80px]">
        {/* Logo */}
        <a href="#" className="flex-shrink-0">
          <img
            src={imgLogo}
            alt="re:H Thailand"
            className="h-[36px] w-auto object-contain"
          />
        </a>

        {/* Desktop Nav */}
        <div className="hidden lg:flex items-center gap-8">
          {navLinks.map((link) => (
            <button
              key={link.label}
              onClick={() => handleNavClick(link.href)}
              className="font-['Inter',sans-serif] font-medium text-[14px] text-[#364153] hover:text-[#155dfc] transition-colors tracking-[0.2px] cursor-pointer bg-transparent border-none"
            >
              {link.label}
            </button>
          ))}
          <button
            onClick={() => handleNavClick("#demo")}
            className="bg-gradient-to-b from-[#0a0a0a] to-[#1a1a1a] text-white font-['Inter',sans-serif] font-medium text-[14px] px-6 py-3 tracking-[0.55px] cursor-pointer border-none hover:opacity-90 transition-opacity"
          >
            Schedule Demo
          </button>
        </div>

        {/* Mobile Hamburger */}
        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className="lg:hidden flex flex-col gap-1.5 cursor-pointer bg-transparent border-none p-2"
        >
          <span className={`block w-6 h-0.5 bg-[#0a0a0a] transition-all ${mobileOpen ? "rotate-45 translate-y-2" : ""}`} />
          <span className={`block w-6 h-0.5 bg-[#0a0a0a] transition-all ${mobileOpen ? "opacity-0" : ""}`} />
          <span className={`block w-6 h-0.5 bg-[#0a0a0a] transition-all ${mobileOpen ? "-rotate-45 -translate-y-2" : ""}`} />
        </button>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="lg:hidden bg-white/95 backdrop-blur-md border-t border-gray-100 px-6 py-4">
          {navLinks.map((link) => (
            <button
              key={link.label}
              onClick={() => handleNavClick(link.href)}
              className="block w-full text-left font-['Inter',sans-serif] font-medium text-[15px] text-[#364153] py-3 border-none bg-transparent cursor-pointer hover:text-[#155dfc]"
            >
              {link.label}
            </button>
          ))}
          <button
            onClick={() => handleNavClick("#demo")}
            className="mt-3 w-full bg-gradient-to-b from-[#0a0a0a] to-[#1a1a1a] text-white font-['Inter',sans-serif] font-medium text-[14px] px-6 py-3 tracking-[0.55px] cursor-pointer border-none"
          >
            Schedule Demo
          </button>
        </div>
      )}
    </nav>
  );
}
