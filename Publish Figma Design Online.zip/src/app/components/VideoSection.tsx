import { useState, useRef } from "react";

export function VideoSection() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(true);

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (videoRef.current.paused) {
      videoRef.current.play();
      setIsPlaying(true);
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
    }
  };

  return (
    <section className="bg-gradient-to-b from-white via-[#f9fafb] to-white py-16 lg:py-24 overflow-hidden">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-12">
        {/* Badge */}
        <div className="flex justify-center mb-6">
          <div className="inline-flex items-center gap-3 bg-white/60 border border-[#e5e7eb] rounded-full px-5 py-2">
            <div className="w-2 h-2 rounded-full bg-[#fb2c36] opacity-80" />
            <span className="font-['Inter',sans-serif] font-medium text-[12px] text-[#364153] tracking-[1.8px] uppercase">
              Official Technology Showcase
            </span>
          </div>
        </div>

        {/* Title */}
        <div className="text-center mb-10">
          <h2 className="font-['Inter',sans-serif] font-bold text-[36px] md:text-[48px] lg:text-[60px] text-[#0a0a0a] tracking-[-1.24px] leading-[1.1]">
            SSCM Technology{" "}
            <span
              className="bg-clip-text"
              style={{
                backgroundImage: "linear-gradient(rgb(30,64,175), rgb(59,130,246), rgb(96,165,250))",
                WebkitTextFillColor: "transparent",
                WebkitBackgroundClip: "text",
              }}
            >
              in Action
            </span>
          </h2>
        </div>

        {/* Video Container */}
        <div className="rounded-3xl overflow-hidden shadow-[0px_25px_50px_-12px_rgba(0,0,0,0.25)] border border-[#e5e7eb] relative" style={{ backgroundImage: "linear-gradient(151deg, #1c398e, #0f172b 50%, #1c398e)" }}>
          {/* Overlay Header */}
          <div className="absolute top-0 left-0 right-0 z-10 bg-gradient-to-b from-black/60 to-transparent p-6 lg:p-8 flex items-center justify-between pointer-events-none">
            <div className="bg-white/10 border border-white/20 rounded-2xl px-5 py-3">
              <p className="font-['Inter',sans-serif] font-bold text-[20px] text-white tracking-[-0.95px]">re:H</p>
              <p className="font-['Inter',sans-serif] font-normal text-[12px] text-[#bedbff] tracking-[0.3px]">SSCM Technology</p>
            </div>
            <div className="bg-[rgba(0,201,80,0.95)] rounded-[14px] px-4 py-1.5 flex items-center gap-2">
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                <circle cx="8" cy="8" r="4" fill="white" opacity="0.6" />
              </svg>
              <span className="font-['Inter',sans-serif] font-semibold text-[12px] text-white tracking-[0.3px]">TFDA Certified</span>
            </div>
          </div>

          {/* Video placeholder */}
          <div className="relative aspect-video bg-gradient-to-br from-[#1c398e]/30 via-transparent to-[#0f172b]/60 flex items-center justify-center min-h-[300px] md:min-h-[400px] lg:min-h-[500px]">
            <video
              ref={videoRef}
              autoPlay
              loop
              playsInline
              muted
              className="absolute inset-0 w-full h-full object-cover"
            >
              <source src="/assets/videos/sscm-showcase.mp4" type="video/mp4" />
            </video>

            {/* Play/Pause button overlay */}
            <div className="relative z-10 flex items-center justify-center">
              <div className={`absolute w-[160px] h-[160px] rounded-full bg-white/30 transition-opacity duration-300 ${isPlaying ? "opacity-0" : "opacity-80"}`} />
              <div className={`absolute w-[212px] h-[212px] rounded-full bg-white/5 transition-opacity duration-300 ${isPlaying ? "opacity-0" : "opacity-100"}`} />
              <button
                onClick={togglePlay}
                className={`relative bg-white rounded-full w-[112px] h-[112px] shadow-[0px_25px_50px_rgba(0,0,0,0.25)] flex items-center justify-center cursor-pointer border-none transition-opacity duration-300 ${isPlaying ? "opacity-0 hover:opacity-70" : "opacity-100"}`}
                aria-label={isPlaying ? "Pause video" : "Play video"}
              >
                {isPlaying ? (
                  <svg width="44" height="44" viewBox="0 0 44 44" fill="none">
                    <rect x="12" y="8" width="7" height="28" rx="2" fill="#0A0A0A" />
                    <rect x="25" y="8" width="7" height="28" rx="2" fill="#0A0A0A" />
                  </svg>
                ) : (
                  <svg width="44" height="44" viewBox="0 0 44 44" fill="none" className="pl-1">
                    <path d="M11 5.5L36.67 22L11 38.5V5.5Z" fill="#0A0A0A" stroke="#0A0A0A" strokeLinecap="round" strokeLinejoin="round" strokeWidth="3.67" />
                  </svg>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}