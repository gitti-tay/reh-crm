import svgPaths from "../../imports/svg-sqg3bg9ea9";

const testimonials = [
  {
    quote: "\"The ±0.01mm precision gives me absolute control. I can target specific depths with confidence I've never experienced with other devices.\"",
    name: "Dr. Thanya Techapichetvanich",
    title: "Asst. Professor of Dermatology",
    institution: "Siriraj Hospital, Bangkok",
  },
  {
    quote: "\"Safety is non-negotiable in my practice. The 13-point monitoring system has eliminated my concerns about adverse events entirely.\"",
    name: "Dr. Mart Maiprasert",
    title: "Dean at College of Integrative Medicine",
    institution: "Dhurakij Pundit University",
  },
  {
    quote: "\"My patients report minimal discomfort and faster recovery compared to traditional needling. The results speak for themselves.\"",
    name: "Dr. Natcha Na Nongkhai",
    title: "Dermatology Doctor",
    institution: "APEX Medical Beauty, Bangkok",
  },
  {
    quote: "\"re:H has transformed how we approach hair scalp revision. The precision and safety profile allow us to treat cases we couldn't before.\"",
    name: "Dr. Chinmanat Lekhavat",
    title: "Hair Surgeon",
    institution: "Institute of Dermatology, Thailand",
  },
];

function QuoteIcon() {
  return (
    <div className="absolute top-6 right-6 opacity-10">
      <svg width="48" height="48" viewBox="0 0 48 48" fill="none" className="overflow-visible">
        <path d={svgPaths.p98a0a70} stroke="#155DFC" strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" transform="translate(0 4)" />
        <path d={svgPaths.p2ce0db40} stroke="#155DFC" strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" transform="translate(18 4)" />
      </svg>
    </div>
  );
}

export function TestimonialsSection() {
  return (
    <section id="evidence" className="bg-white py-16 lg:py-24 overflow-hidden">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-12">
        {/* Badge */}
        <div className="flex justify-center mb-4">
          <div className="inline-flex items-center gap-2 bg-[#eff6ff] border border-[#bedbff] rounded-full px-4 py-2">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <path d={svgPaths.p17f48400} stroke="#155DFC" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33" />
            </svg>
            <span className="font-['Inter',sans-serif] font-semibold text-[14px] text-[#1447e6] tracking-[-0.15px]">
              Endorsed by Medical Professionals
            </span>
          </div>
        </div>

        {/* Header */}
        <div className="text-center mb-10">
          <h2 className="font-['Inter',sans-serif] font-bold text-[32px] md:text-[40px] lg:text-[48px] text-[#101828] tracking-[-0.13px] mb-4">
            Trusted by Asia's Leading Aesthetic Experts
          </h2>
          <p className="font-['Inter',sans-serif] font-normal text-[16px] md:text-[18px] text-[#4a5565] max-w-[670px] mx-auto leading-[1.6] tracking-[-0.44px]">
            Endorsed by professors and clinical directors across Asia's most respected medical institutions
          </p>
        </div>

        {/* Testimonial Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {testimonials.map((t) => (
            <div
              key={t.name}
              className="relative rounded-[14px] border-2 border-[#e5e7eb] p-6"
              style={{ backgroundImage: "linear-gradient(160deg, #f9fafb, #ffffff)" }}
            >
              <QuoteIcon />
              <p className="font-['Inter',sans-serif] font-normal text-[14px] text-[#364153] leading-[1.6] tracking-[-0.15px] mb-6">
                {t.quote}
              </p>
              <div className="border-t border-[#e5e7eb] pt-4 flex items-center gap-3">
                <div className="bg-[#dbeafe] rounded-full w-10 h-10 flex items-center justify-center flex-shrink-0">
                  <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                    <path d={svgPaths.p37143280} stroke="#155DFC" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.67" />
                    <path d={svgPaths.p1d7f0000} stroke="#155DFC" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.67" />
                    <path d={svgPaths.p2b722f80} stroke="#155DFC" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.67" />
                  </svg>
                </div>
                <div>
                  <p className="font-['Inter',sans-serif] font-bold text-[14px] text-[#101828] tracking-[-0.15px]">{t.name}</p>
                  <p className="font-['Inter',sans-serif] font-normal text-[12px] text-[#4a5565]">{t.title}</p>
                  <p className="font-['Inter',sans-serif] font-normal text-[12px] text-[#155dfc]">{t.institution}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <p className="text-center font-['Inter',sans-serif] font-normal text-[14px] text-[#4a5565] tracking-[-0.15px]">
          Explore detailed clinical case studies showcasing real-world results across multiple indications
        </p>
      </div>
    </section>
  );
}
