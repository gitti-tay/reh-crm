import imgDevice from "figma:asset/000ca9a8272dd470779cfc014e6e294d7d9e5dba.png";

export function HeroSection() {
  const scrollTo = (id: string) => {
    const el = document.querySelector(id);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section className="relative min-h-screen bg-gradient-to-b from-white via-[#f9fafb] to-white overflow-hidden pt-[80px]">
      {/* Decorative blurs */}
      <div className="absolute top-[300px] left-1/3 w-[600px] h-[600px] rounded-full blur-[64px] opacity-40" style={{ backgroundImage: "linear-gradient(135deg, rgba(239,246,255,0.4), transparent)" }} />
      <div className="absolute top-[400px] left-[35%] w-[500px] h-[500px] rounded-full blur-[64px] opacity-30" style={{ backgroundImage: "linear-gradient(135deg, rgba(255,251,235,0.3), transparent)" }} />

      <div className="max-w-[1200px] mx-auto px-6 lg:px-12 py-12 lg:py-20">
        <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-8">
          {/* Left content */}
          <div className="flex-1 w-full lg:w-1/2 z-10">
            {/* Badge */}
            <div className="inline-flex items-center gap-3 bg-white/60 border border-[#e5e7eb] rounded-full px-5 py-2 mb-8">
              <div className="w-[6px] h-[6px] rounded-full bg-gradient-to-b from-[#c9a962] to-[#e5d4a6]" />
              <span className="font-['Inter',sans-serif] font-medium text-[12px] text-[#364153] tracking-[1.8px] uppercase">
                TFDA Certified Medical Device
              </span>
            </div>

            {/* Heading */}
            <h1 className="font-['Inter',sans-serif] font-bold text-[42px] md:text-[56px] lg:text-[72px] leading-[1.05] text-[#0a0a0a] tracking-[-1.68px] mb-4">
              Advanced<br />
              Air Subcision<br />
              Microneedling
            </h1>

            {/* Gradient text */}
            <p
              className="font-['Inter',sans-serif] font-bold text-[42px] md:text-[56px] lg:text-[72px] leading-[1.05] tracking-[-1.68px] bg-clip-text mb-6"
              style={{
                backgroundImage: "linear-gradient(rgb(30,64,175), rgb(59,130,246), rgb(96,165,250))",
                WebkitTextFillColor: "transparent",
                WebkitBackgroundClip: "text",
              }}
            >
              with Precision
            </p>

            {/* Description */}
            <p className="font-['Inter',sans-serif] font-light text-[16px] md:text-[18px] lg:text-[20px] leading-[1.8] text-[#4a5565] max-w-[520px] mb-8 tracking-[0.67px]">
              Introducing the patented SSCM platform delivers precise air subcision and drug delivery with{" "}
              <span className="font-bold">±0.01mm</span> depth control and{" "}
              <span className="font-bold">minimal pain</span> level
            </p>

            {/* Feature bullets */}
            <div className="flex flex-col gap-3 mb-10">
              <div className="flex items-start gap-3">
                <div className="w-1 h-1 rounded-full bg-[#c9a962] mt-2.5 flex-shrink-0" />
                <p className="font-['Inter',sans-serif] text-[14px] text-[#0a0a0a] leading-[1.6]">
                  <span className="font-semibold">13-point safety sensors</span>
                  <span className="text-[#364153] font-normal ml-1">with real-time monitoring for absolute clinical safety</span>
                </p>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-1 h-1 rounded-full bg-[#c9a962] mt-2.5 flex-shrink-0" />
                <p className="font-['Inter',sans-serif] text-[14px] leading-[1.6]">
                  <span className="font-semibold text-[#0a0a0a]">Balloon Tip™ & Blow Tip™</span>
                  <span className="text-[#364153] font-normal ml-1">patented air subcision technology</span>
                </p>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-1 h-1 rounded-full bg-[#c9a962] mt-2.5 flex-shrink-0" />
                <p className="font-['Inter',sans-serif] text-[14px] leading-[1.6]">
                  <span className="font-semibold text-[#0a0a0a]">TFDA 66-1-02-0-0018</span>
                  <span className="text-[#364153] font-normal ml-1">• ISO 13485:2016 • Korean Patents</span>
                </p>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-wrap gap-4">
              <button
                onClick={() => scrollTo("#demo")}
                className="bg-gradient-to-b from-[#0a0a0a] to-[#1a1a1a] text-white font-['Inter',sans-serif] font-medium text-[14px] px-8 py-4 tracking-[0.97px] uppercase cursor-pointer border-none hover:opacity-90 transition-opacity flex items-center gap-2"
              >
                Schedule Clinical Demo
                <svg width="13" height="18" viewBox="0 0 13 18" fill="none">
                  <path d="M2.69 9.45H10.21" stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.07" />
                  <path d="M6.45 5.69L10.21 9.45L6.45 13.21" stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.07" />
                </svg>
              </button>
              <button
                onClick={() => scrollTo("#technology")}
                className="border-2 border-[#101828] bg-transparent font-['Inter',sans-serif] font-medium text-[14px] text-[#101828] px-8 py-4 tracking-[0.97px] uppercase cursor-pointer hover:bg-[#101828] hover:text-white transition-colors"
              >
                Explore Technology
              </button>
            </div>
          </div>

          {/* Right device image */}
          <div className="flex-1 w-full lg:w-1/2 flex items-center justify-center relative">
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-[400px] h-[400px] rounded-full blur-[64px]" style={{ backgroundImage: "linear-gradient(135deg, rgba(190,219,255,0.3), rgba(233,212,255,0.2), transparent)" }} />
            </div>
            <img
              src={imgDevice}
              alt="re:H SSCM Device"
              className="relative w-[280px] md:w-[340px] lg:w-[370px] h-auto shadow-[0px_25px_50px_rgba(0,0,0,0.15)] object-contain"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
