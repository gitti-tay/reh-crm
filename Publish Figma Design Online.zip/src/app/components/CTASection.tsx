import { useState } from "react";
import svgPaths from "../../imports/svg-sqg3bg9ea9";

const features = [
  {
    title: "45-Min On-Site Demo",
    subtitle: "Personalized at your clinic",
    icon: (
      <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
        <path d={svgPaths.p1aae36c0} stroke="white" strokeLinecap="round" strokeLinejoin="round" />
        <path d={svgPaths.p1dd4fd00} stroke="white" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    ),
  },
  {
    title: "Live Technology Showcase",
    subtitle: "Real-time precision testing",
    icon: (
      <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
        <path d={svgPaths.p37f49070} stroke="white" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    ),
  },
  {
    title: "Clinical Protocol Review",
    subtitle: "Tailored recommendations",
    icon: (
      <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
        <path d={svgPaths.p209c4100} stroke="white" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    ),
  },
];

export function CTASection() {
  const [form, setForm] = useState({ name: "", clinic: "", email: "", phone: "", message: "" });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 3000);
  };

  return (
    <section id="demo" className="bg-gradient-to-b from-[#f9fafb] via-[rgba(43,127,255,0.15)] to-[#1447e6] py-16 lg:py-24 overflow-hidden">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-12">
        {/* Title */}
        <div className="text-center mb-12">
          <h2 className="font-['Inter',sans-serif] font-bold text-[36px] md:text-[48px] lg:text-[60px] tracking-[-1.24px] leading-[1.1]">
            <span className="text-[rgba(43,127,255,0.5)]">Request a</span>
          </h2>
          <h2
            className="font-['Inter',sans-serif] font-bold text-[36px] md:text-[48px] lg:text-[60px] tracking-[-1.24px] leading-[1.1] bg-clip-text"
            style={{
              backgroundImage: "linear-gradient(90deg, #1447e6, rgba(21,93,252,0.7) 50%, rgba(43,127,255,0.5))",
              WebkitTextFillColor: "transparent",
              WebkitBackgroundClip: "text",
            }}
          >
            Clinical Demo
          </h2>
        </div>

        {/* Form Card */}
        <div className="max-w-[1000px] mx-auto bg-white rounded-3xl shadow-[0px_25px_50px_-12px_rgba(0,0,0,0.25)] overflow-hidden flex flex-col lg:flex-row">
          {/* Left - Form */}
          <div className="flex-1 bg-[#eff6ff] p-8 lg:p-12">
            <h3 className="font-['Inter',sans-serif] font-bold text-[24px] text-[#0a0a0a] tracking-[-0.53px] mb-1">
              Request a Clinical Demo
            </h3>
            <p className="font-['Inter',sans-serif] font-light text-[16px] text-[#4a5565] tracking-[-0.31px] mb-6">
              We'll contact you within 24 hours
            </p>

            <form onSubmit={handleSubmit} className="flex flex-col gap-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <input
                  type="text"
                  placeholder="Full Name *"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  required
                  className="h-[50px] px-5 rounded-[14px] border border-[#d1d5dc] font-['Inter',sans-serif] font-normal text-[14px] text-[#0a0a0a] tracking-[-0.15px] outline-none focus:border-[#155dfc] transition-colors bg-white"
                />
                <input
                  type="text"
                  placeholder="Clinic Name *"
                  value={form.clinic}
                  onChange={(e) => setForm({ ...form, clinic: e.target.value })}
                  required
                  className="h-[50px] px-5 rounded-[14px] border border-[#d1d5dc] font-['Inter',sans-serif] font-normal text-[14px] text-[#0a0a0a] tracking-[-0.15px] outline-none focus:border-[#155dfc] transition-colors bg-white"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <input
                  type="email"
                  placeholder="Email Address *"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  required
                  className="h-[50px] px-5 rounded-[14px] border border-[#d1d5dc] font-['Inter',sans-serif] font-normal text-[14px] text-[#0a0a0a] tracking-[-0.15px] outline-none focus:border-[#155dfc] transition-colors bg-white"
                />
                <input
                  type="tel"
                  placeholder="Phone Number *"
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  required
                  className="h-[50px] px-5 rounded-[14px] border border-[#d1d5dc] font-['Inter',sans-serif] font-normal text-[14px] text-[#0a0a0a] tracking-[-0.15px] outline-none focus:border-[#155dfc] transition-colors bg-white"
                />
              </div>
              <textarea
                placeholder="Message / Questions (Optional)"
                value={form.message}
                onChange={(e) => setForm({ ...form, message: e.target.value })}
                rows={3}
                className="px-5 py-3.5 rounded-[14px] border border-[#d1d5dc] font-['Inter',sans-serif] font-normal text-[14px] text-[#0a0a0a] tracking-[-0.15px] outline-none focus:border-[#155dfc] transition-colors resize-none bg-white"
              />
              <button
                type="submit"
                className="h-[52px] bg-gradient-to-b from-[#1447e6] to-[#1a1a1a] rounded-[14px] font-['Inter',sans-serif] font-medium text-[14px] text-white tracking-[0.97px] uppercase cursor-pointer border-none hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
              >
                {submitted ? "✓ Request Sent!" : (
                  <>
                    Schedule Clinical Demo
                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                      <path d="M3.75 9H14.25" stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
                      <path d="M9 3.75L14.25 9L9 14.25" stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
                    </svg>
                  </>
                )}
              </button>
            </form>
          </div>

          {/* Right - Info */}
          <div className="lg:w-[400px] p-8 lg:p-12 text-white relative overflow-hidden" style={{ backgroundImage: "linear-gradient(124deg, #155dfc, #193cb8)" }}>
            <div className="absolute w-40 h-40 rounded-full bg-white/10 blur-[64px] -top-10 right-0" />
            <h4 className="font-['Inter',sans-serif] font-bold text-[20px] tracking-[-0.95px] mb-8">
              What's Included:
            </h4>

            <div className="flex flex-col gap-6 mb-8">
              {features.map((f) => (
                <div key={f.title} className="flex items-start gap-4">
                  <div className="bg-[rgba(43,127,255,0.5)] rounded-[14px] w-8 h-8 flex items-center justify-center flex-shrink-0">
                    {f.icon}
                  </div>
                  <div>
                    <p className="font-['Inter',sans-serif] font-semibold text-[14px] text-white tracking-[-0.15px]">{f.title}</p>
                    <p className="font-['Inter',sans-serif] font-normal text-[12px] text-[#dbeafe]">{f.subtitle}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="border-t border-[#2b7fff] pt-6 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                  <path d={svgPaths.p3b83c880} stroke="#8EC5FF" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                <span className="font-['Inter',sans-serif] font-normal text-[12px] text-[#dbeafe]">+66 61 361 4599</span>
              </div>
              <div className="flex items-center gap-3">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                  <path d={svgPaths.p124eba00} stroke="#8EC5FF" strokeLinecap="round" strokeLinejoin="round" />
                  <path d={svgPaths.p28233b60} stroke="#8EC5FF" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                <span className="font-['Inter',sans-serif] font-normal text-[12px] text-[#dbeafe]">sales@jnacorporation.com</span>
              </div>
              <div className="flex items-center gap-3">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                  <path d={svgPaths.p321f4d00} stroke="#8EC5FF" strokeLinecap="round" strokeLinejoin="round" />
                  <path d={svgPaths.p3a5e5a00} stroke="#8EC5FF" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                <span className="font-['Inter',sans-serif] font-normal text-[12px] text-[#dbeafe]">Bangkok, Thailand</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}