import { defineConfig, Plugin } from 'vite'
import path from 'path'
import tailwindcss from '@tailwindcss/vite'
import react from '@vitejs/plugin-react'

/**
 * Custom Vite plugin to resolve `figma:asset/` imports.
 * 
 * In Figma Make, these are handled by an internal plugin.
 * For standalone deployment, this plugin maps them to files
 * in the /public/assets/ directory.
 * 
 * Example: `import img from "figma:asset/abc123.png"`
 * Resolves to: `export default "/assets/abc123.png"`
 * The actual file should be at: /public/assets/abc123.png
 */
function figmaAssetPlugin(): Plugin {
  const VIRTUAL_PREFIX = '\0figma-asset:'

  return {
    name: 'figma-asset-resolver',
    enforce: 'pre',
    resolveId(source) {
      if (source.startsWith('figma:asset/')) {
        const filename = source.replace('figma:asset/', '')
        return VIRTUAL_PREFIX + filename
      }
      return null
    },
    load(id) {
      if (id.startsWith(VIRTUAL_PREFIX)) {
        const filename = id.replace(VIRTUAL_PREFIX, '')
        return `export default "/assets/${filename}"`
      }
      return null
    },
  }
}

export default defineConfig({
  plugins: [
    figmaAssetPlugin(),
    react(),
    tailwindcss(),
  ],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  assetsInclude: ['**/*.svg', '**/*.csv'],
})
